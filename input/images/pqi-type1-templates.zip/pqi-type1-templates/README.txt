PQI Type 1 templates (ICH M4Q(R1) headings)

Blank FHIR R5 document Bundles conforming to the PQI Type 1 profiles of the HL7 FHIR Pharmaceutical Quality
Information (PQI) IG (http://hl7.org/fhir/uv/pharm-quality). One document per heading:

  2.3          Quality Overall Summary
  3.2.S.1-7    Drug substance (one document per level-3 heading)
  3.2.P.1-8    Drug product (one document per level-3 heading)
  3.2.A.1-3    Appendices
  3.2.R        Regional information (sub-sections use the regulator's own headings)
  3.2 collection   all Module 3.2 templates in one PQI document collection Bundle

Each lowest-level heading is marked "Not started" (narrative status "empty", emptyReason "notstarted").
Before use:
  * replace the bracketed metadata: [Product name], [Applicant], the subject, and the document date
    (the template carries a data-absent-reason extension instead of a date);
  * give each Bundle a new identifier (the template identifiers are placeholders);
  * replace "Not started" with content, set the narrative status to "additional" and remove emptyReason;
  * for several drug substances, copy the 3.2.S documents (and the 2.3.S section) once per substance and
    give each repeat a distinct section title.
