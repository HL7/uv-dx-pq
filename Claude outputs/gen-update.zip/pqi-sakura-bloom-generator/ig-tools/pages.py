import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ui import *

OUT = sys.argv[1]
SD = lambda id_, name: a(f"StructureDefinition-{id_}.html", name)
CS_URL = "http://hl7.org/fhir/uv/pharm-quality/CodeSystem/ctd-section-pq"
def write(name, s): open(os.path.join(OUT, name), "w").write(s)

TYPES = [
    ("build_type1.html", "Type 1", "Structured document", "📄", "#2563eb", "CTD headings coded, narrative and images as in the Word document."),
    ("build_type2.html", "Type 2", "Document + product data", "🏷️", "#0891b2", "Adds product, packaging, organization, substance and authorization resources."),
    ("build_type3.html", "Type 3", "Linked document", "🔗", "#7c3aed", "Links each section's narrative to the PQI resources it discusses."),
    ("build_type4.html", "Type 4", "Data-first document", "🧬", "#16a34a", "Resources replace narrative where they carry the content."),
]

# ============================================================ build.md (overview)
s = comment("PQI BUILD — Overview | Target: business/regulatory users")
s += header_note("📋", "New to PQI?", "Start with a Type 1 document: convert your Module 2.3 or Module 3 Word document into a FHIR document with coded CTD headings, then move up one type at a time.")
s += p("Most quality dossiers are still authored as Word documents under the ICH M4Q headings. The <strong>Build</strong> section shows how to move from there, one step at a time, to fully structured pharmaceutical quality data. Each step is a <strong>PQI type</strong> (maturity level), and each type is a FHIR document: a "
       + code("Bundle") + " of type " + code("document") + " whose first entry is a " + code("Composition") + ".")
s += h3("Select your implementation path", mb=12)
s += '<div style="display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:24px;">\n'
for href, t, name, icon, col, txt in TYPES:
    s += (f'  <a href="{href}" style="text-decoration:none; background:#fff; border:1px solid #e5e7eb; border-top:3px solid {col}; border-radius:8px; padding:16px 18px; display:block;">\n'
          f'    <div style="font-size:1.3em; margin-bottom:6px;">{icon}</div>\n'
          f'    <div style="font-size:.72em; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#9ca3af; margin-bottom:4px;">{t}</div>\n'
          f'    <div style="font-weight:700; color:#111827; margin-bottom:6px;">{name}</div>\n'
          f'    <div style="font-size:.82em; color:#6b7280; line-height:1.5;">{txt}</div>\n  </a>\n')
s += "</div>\n"
s += h3("The four types at a glance", mb=12)
s += table(["", "Type 1", "Type 2", "Type 3", "Type 4"], [
    ["<strong>Bundle profile</strong>", SD("Bundle-document-type1-pq", "BundleDocumentType1Pq"), SD("Bundle-document-type2-pq", "BundleDocumentType2Pq"), SD("Bundle-document-type3-pq", "BundleDocumentType3Pq"), SD("Bundle-document-type4-pq", "BundleDocumentType4Pq")],
    ["<strong>Composition profile</strong>", SD("Composition-type1-pq", "CompositionType1Pq"), SD("Composition-type2-pq", "CompositionType2Pq"), SD("Composition-type3-pq", "CompositionType3Pq"), SD("Composition-type4-pq", "CompositionType4Pq")],
    ["<strong>Section headings</strong>", "M4Q(R1) template, coded", "Same", "Same", "Same"],
    ["<strong>Section narrative</strong>", "Required, authored", "Required, authored", "Required, with " + code("id") + " anchors", "Optional on replaceable headings"],
    ["<strong>Images</strong>", code("Binary") + " + " + code("DocumentReference") + " entries", "Same", "Same", "Same"],
    ["<strong>Other resources</strong>", "None", "Product, packaging, organizations, substances, authorization", "Type 2 + any PQI domain resource", "Same as Type 3"],
    ["<strong>" + code("section.entry") + "</strong>", "Image DocumentReferences only", "Product data section, plus images", "Any CTD section, linked to the narrative with " + code("textLink"), "Any CTD section; sole content of replaceable sections"],
    ["<strong>Effort</strong>", "Convert the Word template", "+ map master data", "+ link narrative to data", "+ generate data from source systems"],
], widths=["18%", None, None, None, None])
s += sp("Each type builds on the one before, so tooling and examples can be layered.", mb=24)

s += h3("Which type should I build?", mb=12)
s += table(["You are…", "Start with"], [
    ["A sponsor whose Module 2.3 and Module 3 live in Word", a("build_type1.html", "Type 1")],
    ["A sponsor with a RIM or IDMP system holding product master data", a("build_type2.html", "Type 2")],
    ["A vendor of CMC authoring tools", a("build_type3.html", "Type 3")],
    ["A sponsor whose quality data lives in LIMS, MES or QMS systems", a("build_type4.html", "Type 4")],
], widths=["65%", None], mb=24)

s += hr() + h3("Document granularity", id="document-granularity")
s += p("The IG fixes how a dossier is cut into documents; implementers do not choose. That lets a document be reused unchanged across markets, and replaced on its own when one part changes.")
s += cards([
    ("🧾", "Module 2.3", "One document", "A single Quality Overall Summary document with one top-level section coded " + code("2.3") + ".", "#2563eb"),
    ("🗂️", "Module 3.2", "One document per level-3 heading", "3.2.S.1–3.2.S.7 per drug substance (and manufacturer), 3.2.P.1–3.2.P.8 per drug product, 3.2.A.1–3.2.A.3 per item, 3.2.R per region.", "#0891b2"),
    ("📦", "Sent together", "Document collection", "Any group of documents is sent as a " + SD("Bundle-document-collection-pq", "BundleDocumentCollectionPq") + ". Documents in one collection can be at different types.", "#7c3aed"),
])
s += callout("⚡ Reuse across markets", "The same manufacturing process means the same <strong>3.2.P.3</strong> document everywhere; a market-specific formulation means a different <strong>3.2.P.1</strong> for that market. One drug substance plus one drug product is 15 documents (7 + 8), plus any 3.2.A and 3.2.R documents.")
s += ul(["Each Module 3.2 document has exactly one CTD top-level section, coded from " + a("ValueSet-vs-ctd-document-root-pq.html", "vs-ctd-document-root-pq") + ", and names its drug substance or drug product in " + code("Composition.subject") + ".",
         "Lower-level headings (e.g. 3.2.P.3.1) stay as sections inside their document. Small documents (e.g. 3.2.S.5) are never merged, and one document never spans several level-3 headings.",
         "Documents in one collection can be at different types, e.g. 3.2.P.3 at Type 4 next to 3.2.P.2 at Type 1, so maturity can grow one document at a time.",
         "Resources that appear in several documents keep the same identifiers, so links between documents resolve by identifier, not by Bundle-local id.",
         "How documents and collections are exchanged is out of scope for now."])

s += hr() + h3("Section headings", id="section-headings")
s += p("Sections are coded with " + a("CodeSystem-ctd-section-pq.html", "CtdSectionPq") + ", which holds the ICH M4Q(R1) headings of Module 2.3 and Module 3.2. M4Q(R1) is final and implemented; M4Q(R2) is still a draft, so its headings will be added once ICH finalizes it. For 3.2.R only the top-level heading is coded: sub-sections carry the regulator's own headings.")
s += callout("Focus vs. entry", "A heading that can repeat inside one document (2.3.S per drug substance, 2.3.P per drug product, listed in " + a("ValueSet-vs-ctd-repeatable-pq.html", "vs-ctd-repeatable-pq", "#d97706") + ") is repeated as a sibling section. From Type 2 on, each repeat names what it is about in " + code("section.focus") + "; in Type 1 the repeats are told apart by " + code("section.title") + ". <strong>Focus says what a whole section is about, entry says what data is in it.</strong> The focus target never also appears in the same section's entries.", "yellow")

s += hr() + h3("How the types relate to the domain Bundles")
s += p("The " + a("domains.html", "domain") + " collection Bundles (e.g. " + a("organizations.html", "Organizations") + ", " + a("stability.html", "Stability Study") + ") remain the way to exchange one kind of quality data. In Types 2–4 the same resource profiles appear inside documents, and in Type 4 they become the content model of the sections whose narrative they replace.")
s += callout("🛡️ Design principle", "Profiles carry the structural rules, and quality checks live in external validation. Rules that FHIRPath cannot check reliably – such as narrative anchors and image references – are stated as conformance rules and enforced by implementers' validation apps. See " + a("build_validate.html", "Validate and QA", "#1d4ed8") + ".")
s += hr() + whats_next(("build_type1.html", "Type 1 Structured document", "Convert your Module 2.3 or Module 3 Word document into a FHIR document with coded CTD headings."),
                       ("build_validate.html", "Validate and QA", "Validator commands, invariants and the quality checks for validation apps."))
s += tip("Synthetic example data:", "the worked examples in this guide are fictitious. They use synthetic data from the ICH M4Q(R2) Sakura Bloom mock-up, the FDA example Quality Overall Summaries and the HL7 FHIR PQI team. They do not describe a real product, company or authorization, and every document is labelled as test data (HTEST).")
write("build.md", s)

# ============================================================ build_type1.md
s = comment("PQI TYPE 1 — Build Guide | Target: business/regulatory users")
s += comment("PRE-REQUISITES") + '<div id="prerequisites" style="margin-bottom:32px;">\n'
s += h3("Before You Start", mb=6) + '<p style="color:#6b7280; font-size:.92em; margin-bottom:20px;">Have these three things ready before building a PQI document.</p>\n'
s += cards([
    ("📖", "Step A", "Read the Build overview", "Understand the four PQI types, " + a("build.html#document-granularity", "document granularity") + " and coded section headings.", "#2563eb"),
    ("🗂️", "Step B", "Get the template", "The ICH M4Q(R1) headings, or a regulator's template built on them (e.g. Health Canada QOS-CE, QOS-B, CPID-CE, CPID-B).", "#0891b2"),
    ("🛠️", "Step C", "Get a converter", "A structured authoring tool or converter from Word to the FHIR XHTML narrative subset.", "#7c3aed"),
], mb=8) + "</div>\n" + hr()
s += comment("WHAT IS TYPE 1") + h3("What is PQI Type 1?")
s += p("A PQI Type 1 document is the digital equivalent of a Module 2.3 Quality Overall Summary, or of one level-3 Module 3.2 heading, converted 1:1 into a FHIR document. It keeps the ICH M4Q(R1) headings, the full narrative, tables and images, so the document is machine-readable while remaining human-readable. It is the easiest path to a structured document.")
s += badges([("📦 Bundle", "blue"), ("📄 Composition", "teal"), ("🖼️ Binary (images)", "purple"), ("🏷️ DocumentReference (figures)", "amber")])
s += comment("RESOURCE CHAIN VISUAL") + chain("How the Type 1 resources connect", [
    (0, None, [("Bundle (document)", "blue")]),
    (1, "contains", [("Composition", "teal"), ("Binary", "purple"), ("DocumentReference", "amber")]),
    (2, "section.entry references", [("DocumentReference", "amber")]),
    (3, "attachment points at", [("Binary", "purple")]),
])
s += hr() + h3("Step-by-Step Workflow", mb=20)
s += step(1, "Pick the document and template",
    sp("One document for Module 2.3; one document per level-3 Module 3.2 heading. Your answers drive the document's core metadata.", 14)
    + table(["Question", "Drives this field"], [
        ["Module 2.3 QOS or a Module 3.2 heading?", code("Composition.type") + " = " + code("m2-3-qos") + " or " + code("m3-2-quality") + " (" + a("CodeSystem-pqi-document-type.html", "PqiDocumentType") + ")"],
        ["Which maturity type?", code("Composition.category") + " = " + code("type-1") + " (" + a("CodeSystem-pqi-maturity-type.html", "PqiMaturityType") + ")"],
        ["Which drug substance or drug product?", code("Composition.subject.display") + " (product name, manufacturer or dosage form)"],
        ["Which applicant?", code("Composition.author.display")],
    ], widths=["40%", None])
    + tip("Start from a skeleton:", "the " + a("Bundle-bundle-document-type1-pq-m23-r1-skeleton.html", "Module 2.3 skeleton", "#92400e") + " and the " + a("Bundle-bundle-document-collection-pq-m32-r1-skeleton.html", "Module 3.2 skeleton collection", "#92400e") + " contain every M4Q(R1) heading, coded, with no content."))
s += step(2, "Copy the heading tree",
    sp("Every heading of the template appears, in order, as a " + code("section") + " with its " + a("CodeSystem-ctd-section-pq.html", "CtdSectionPq") + " code and title. Headings marked \"Not applicable\" keep their section and narrative, as in the Word original.", 14)
    + compare("Word: headings", "<strong>3.2.P.3 MANUFACTURE</strong><br/>3.2.P.3.1 Manufacturer(s)<br/>3.2.P.3.2 Batch Formula<br/>3.2.P.3.3 Description of Manufacturing Process…",
              "PQI: coded sections", '<span style="color:#0891b2;">&lt;section code="3.2.P.3"&gt;</span><br/>&nbsp;&nbsp;<span style="color:#2563eb;">&lt;section code="3.2.P.3.1"/&gt;</span><br/>&nbsp;&nbsp;<span style="color:#2563eb;">&lt;section code="3.2.P.3.2"/&gt;</span><br/>&nbsp;&nbsp;<span style="color:#2563eb;">&lt;section code="3.2.P.3.3"/&gt;</span><br/><span style="color:#0891b2;">&lt;/section&gt;</span>', bad=False)
    + tip("Repeated headings:", "where 2.3.S or 2.3.P repeats (several drug substances or products), give each repeat a distinct " + code("section.title") + ", e.g. \"2.3.S Drug Substance – Sakuramil\"."))
s += step(3, "Convert the content to narrative",
    sp("Put the content of each heading into " + code("section.text") + " (" + code("status = additional") + "). Every leaf section has narrative.", 14)
    + callout("Formatting vs. Styling", "<strong>Embedded formatting is required</strong> for structure and meaning (headings, lists, bold, italics, tables). <strong>Styling is never embedded</strong>: page orientation, fonts, font sizes, text colour, table shading and borders are applied by style sheets.", "yellow")
    + table(["Word content", "In the narrative"], [
        ["Paragraphs, lists, bold, italic, sub/superscript", "The matching XHTML elements"],
        ["Tables, including merged cells", "XHTML tables (" + code("colspan") + " / " + code("rowspan") + ")"],
        ["Footnotes", "Paragraphs at the end of the section"],
        ["Cross-references", "In-document anchors"],
        ["Tracked changes", "The " + a("https://build.fhir.org/ig/HL7/emedicinal-product-info/en/tracked-changes.html", "ePI tracked-changes method") + ": insert/delete anchors plus an annotations section"],
        ["Text boxes", '<span style="color:#b91c1c; font-weight:600;">Not supported</span>: move their content into the body text'],
    ], widths=["40%", None]))
s += step(4, "Add images as Binary + DocumentReference",
    sp("Images are separate Bundle entries, not contained resources, so the Composition stays light and images load separately. Images go in at full resolution.", 14)
    + mini([("🖼️", "A. Binary", "Add a " + code("Binary") + " entry with the image bytes and an " + code("image/*") + " contentType"),
            ("🏷️", "B. DocumentReference", "Add a " + a("StructureDefinition-DocumentReference-drug-pq.html", "DocumentReferenceDrugPq") + " with figure type, caption, and an attachment pointing at the Binary (contentType, size, hash)"),
            ("🔗", "C. Show & reference", "Show it with " + code('<img src="Binary/[id]"/>') + " and add the DocumentReference to " + code("section.entry")),
            ])
    + tip("Shared images:", "an image used in two documents is copied into both, with the same identifier, so each document stays self-contained."))
s += step(5, "Assemble the Bundle and validate",
    sp("Wrap the Composition, Binary and DocumentReference entries in a " + code("Bundle") + " of " + code("type: document") + ". Nothing else goes in a Type 1 Bundle.", 14)
    + table(["Bundle field", "What to enter"], [
        [code("identifier"), "A unique document identifier"], [code("type"), "Always <strong>document</strong>"],
        [code("timestamp"), "Date/time the Bundle was assembled (ISO 8601)"],
        [code("entry[0]"), "Must be the Composition; Binary and DocumentReference entries follow"],
    ], widths=["30%", None])
    + ok("Validate:", "run the Bundle against " + a("StructureDefinition-Bundle-document-type1-pq.html", "BundleDocumentType1Pq", "#15803d") + ". See " + a("build_validate.html", "Validate and QA", "#15803d") + " for the invariants and quality checks."), mb=28)
s += step(6, "Group documents that are sent together",
    sp("Send a full Module 3.2, or any subset of documents, as a " + a("StructureDefinition-Bundle-document-collection-pq.html", "BundleDocumentCollectionPq") + ". Related documents can also point to each other with " + code("Composition.relatesTo") + ".")
    + callout("📏 Granularity rule", "Never merge several level-3 headings into one Composition, and never merge small documents into larger ones. See " + a("build.html#document-granularity", "Document granularity", "#1d4ed8") + "."), mb=28)
s += hr() + h3("Worked example", mb=12)
s += sp("With content, the 3.2.P.3.3 section and its process flow diagram look like this:", 10)
s += pre('''{
  "title": "Description of Manufacturing Process and Process Controls",
  "code": { "coding": [{ "system": "''' + CS_URL + '''", "code": "3.2.P.3.3" }] },
  "text": {
    "status": "additional",
    "div": "<div xmlns=\\"http://www.w3.org/1999/xhtml\\"><p>The tablets are manufactured by …</p><img src=\\"Binary/img-3-2-p-3-3-flow\\"/></div>"
  },
  "entry": [{ "reference": "DocumentReference/fig-3-2-p-3-3-flow" }]
}''')
s += tip("Example:", a("Bundle-bundle-document-collection-pq-sakura-bloom-type1.html", "Sakura Bloom Type 1 collection", "#92400e") + " — 3.2.P.3, 3.2.P.7 and 3.2.R (US) from the ICH Sakura Bloom mock-up. The mock-up extract has no image files, so figures are labelled placeholder images. All example data is synthetic, drawn from the ICH Sakura Bloom mock-up, the FDA example Quality Overall Summaries and the HL7 FHIR PQI team’s example data; anything none of these provide is marked as synthetic where it appears.")
s += hr() + h3("Checklist", mb=12) + checklist([
    "One document per Module 2.3, or per level-3 Module 3.2 heading",
    "Every template heading present, in order, coded and titled",
    "Every leaf section has narrative; no embedded styling",
    "Every image is a " + code("Binary") + " + " + code("DocumentReference") + " pair, shown with " + code('<img src="Binary/[id]"/>'),
    "No contained resources and no other resources in the Bundle",
    "Repeated 2.3.S / 2.3.P sections have distinct titles",
], mb=16)
s += sp("Profiles: " + SD("Bundle-document-type1-pq", "BundleDocumentType1Pq") + ", " + SD("Composition-type1-pq", "CompositionType1Pq") + ". Invariants: " + ", ".join(code(x) for x in ["pqi-doc-1", "pqi-sec-0", "pqi-sec-1", "pqi-sec-2", "pqi-gran-1", "pqi-foc-1", "pqi-foc-3", "pqi-txt-1", "pqi-t1-1"]) + ".")
s += hr() + whats_next(("build_type2.html", "Type 2 Document + product data", "Keep the narrative and add the product's master data: product, packaging, organizations, substances and authorization."))
write("build_type1.md", s)

# ============================================================ build_type2.md
s = comment("PQI TYPE 2 — Build Guide | Target: business/regulatory users")
s += header_note("📋", "Before you start:", "you need a " + a("build_type1.html", "Type 1 document", "#1e40af") + " and an export of the product master data from your RIM or IDMP/SPOR system.")
s += comment("WHAT IS TYPE 2") + h3("What is PQI Type 2?")
s += p("A PQI Type 2 document keeps the Type 1 narrative unchanged and adds the product's master data as resources in the same Bundle. This is the identity and regulatory context a reviewer or a RIM system needs before reading any CMC detail.")
s += badges([("📦 Bundle", "blue"), ("📄 Composition", "teal"), ("💊 MedicinalProductDefinition", "rose"), ("🧪 ManufacturedItemDefinition", "amber"), ("💉 AdministrableProductDefinition", "amber"),
             ("📦 PackagedProductDefinition", "slate"), ("⚗️ Ingredient", "green"), ("🧬 SubstanceDefinition", "green"), ("🏭 Organization", "purple"), ("📜 RegulatedAuthorization", "blue")])
s += chain("How the Type 2 resources connect", [
    (0, None, [("Composition", "teal")]),
    (1, "subject", [("MedicinalProductDefinition", "rose"), ("or SubstanceDefinition (3.2.S)", "green")]),
    (1, "author", [("Organization (applicant)", "purple")]),
    (1, "section pqi-product-data lists", [("ManufacturedItemDefinition", "amber"), ("AdministrableProductDefinition", "amber"), ("PackagedProductDefinition", "slate"), ("Ingredient", "green"), ("Organization", "purple"), ("RegulatedAuthorization", "blue")]),
    (1, "CTD sections reference", [("image DocumentReferences only", "slate")]),
])
s += h3("Resources added", mb=12)
s += table(["Content", "Profile"], [
    ["Drug product identity, strength, dose form, route", SD("MedicinalProductDefinition-drug-product-pq", "MedicinalProductDefinitionDrugProductPq")],
    ["Manufactured item (e.g. tablet core and coat)", SD("ManufacturedItemDefinition-drug-pq", "ManufacturedItemDefinitionDrugPq")],
    ["Administrable product (dose form and route as given, including reconstitution); optional", SD("AdministrableProductDefinition-drug-pq", "AdministrableProductDefinitionPq")],
    ["Packaging and container closure", SD("PackagedProductDefinition-drug-pq", "PackagedProductDefinitionDrugPq")],
    ["Qualitative and quantitative composition", SD("Ingredient-drug-pq", "IngredientDrugPq")],
    ["Drug substance, excipients, impurities", SD("SubstanceDefinition-component-substance-drug-pq", "SubstanceDefinitionComponentSubstanceDrugPq")],
    ["Applicant, manufacturers, test sites, packagers", SD("Organization-drug-pq", "OrganizationDrugPq")],
    ["Marketing authorization or application", SD("RegulatedAuthorization-drug-pq", "RegulatedAuthorizationPq")],
], widths=["50%", None], mb=24)
s += hr() + h3("Step-by-Step Workflow", mb=20)
s += step(1, "Start from the Type 1 document", sp("Set " + code("Composition.category") + " to " + code("type-2") + ". The narrative and images stay exactly as they are."))
s += step(2, "Reference the product and the applicant",
    sp("Point " + code("Composition.subject") + " at the " + code("MedicinalProductDefinition") + " (or, in a 3.2.S document, at the drug substance " + code("SubstanceDefinition") + "), and " + code("Composition.author") + " at the applicant " + code("Organization") + "."))
s += step(3, "Add the Product data section",
    sp("Add a first top-level section coded " + code("pqi-product-data") + ". Its " + code("entry") + " lists every other product data resource; its " + code("text") + " is generated (" + code("status = generated") + "), e.g. a summary table of product, packs, sites and authorizations.", 14)
    + warn("Keep the CTD sections as in Type 1:", "in Type 2 they still reference only image DocumentReferences. Linking resources to CTD sections is " + a("build_type3.html", "Type 3", "#7f1d1d") + "."))
s += step(4, "Set focus on repeated headings",
    sp("Where 2.3.S or 2.3.P repeats in the Module 2.3 document, set " + code("section.focus") + " on each repeat to its drug substance or drug product.", 14)
    + compare("Type 1: title only", "2.3.S Drug Substance – Sakuramil<br/>2.3.S Drug Substance – Compound B",
              "Type 2: focus", '<span style="color:#0891b2;">&lt;section code="2.3.S"&gt;</span> focus → SubstanceDefinition/sakuramil<br/><span style="color:#0891b2;">&lt;section code="2.3.S"&gt;</span> focus → SubstanceDefinition/compound-b', bad=False))
s += step(5, "Add the resources and validate",
    sp("Add the resources to the Bundle. Use the same identifiers in every document that carries the same resource.", 14)
    + ok("Validate:", "run the Bundle against " + a("StructureDefinition-Bundle-document-type2-pq.html", "BundleDocumentType2Pq", "#15803d") + "."), mb=28)
s += callout("♻️ Maintain product data once", "The same " + code("MedicinalProductDefinition") + ", " + code("PackagedProductDefinition") + ", " + code("AdministrableProductDefinition") + " and " + code("Organization") + " instances can be shared with IDMP submissions.", "green")
s += tip("Example:", a("Bundle-bundle-document-collection-pq-sakura-bloom-type2.html", "Sakura Bloom Type 2 collection", "#92400e") + " — 3.2.P.3, 3.2.P.7 and 3.2.R (US) from the ICH Sakura Bloom mock-up. Each document adds a subject, an author and a Product data section; the drug product documents include a made-up US marketing authorization. All example data is synthetic, drawn from the ICH Sakura Bloom mock-up, the FDA example Quality Overall Summaries and the HL7 FHIR PQI team’s example data; anything none of these provide is marked as synthetic where it appears.")
s += hr() + h3("Checklist", mb=12) + checklist([
    code("subject") + " and " + code("author") + " reference resources in the Bundle",
    "One Product data section, first, with generated narrative, listing every product data resource",
    "CTD sections reference only image DocumentReferences",
    "Repeated 2.3.S / 2.3.P sections carry " + code("section.focus"),
    "Shared resources keep the same identifiers across documents",
], mb=16)
s += sp("Profiles: " + SD("Bundle-document-type2-pq", "BundleDocumentType2Pq") + ", " + SD("Composition-type2-pq", "CompositionType2Pq") + ". Invariants: the Type 1 set (except " + code("pqi-t1-1") + "), plus " + ", ".join(code(x) for x in ["pqi-foc-2", "pqi-t2-1"]) + ".")
s += hr() + whats_next(("build_type3.html", "Type 3 Linked document", "Link each section's narrative to the PQI resources it discusses."))
write("build_type2.md", s)

# ============================================================ build_type3.md
s = comment("PQI TYPE 3 — Build Guide | Target: authoring tool vendors, sponsors")
s += header_note("📋", "Before you start:", "you need a " + a("build_type2.html", "Type 2 document", "#1e40af") + ", the PQI domain resources the narrative discusses, and a mapping from the narrative to those resources.")
s += h3("What is PQI Type 3?")
s += p("A PQI Type 3 document keeps every section's authored narrative and links it to PQI resources, so a reviewer can move from a sentence straight to the data behind it. A human can still read the document without the links.")
s += badges([("📋 PlanDefinition", "blue"), ("🎯 ObservationDefinition", "teal"), ("📊 Observation", "green"), ("📑 DiagnosticReport", "green"), ("💊 Medication (batches)", "rose"),
             ("⚗️ Substance", "amber"), ("🧫 Specimen / SpecimenDefinition", "purple"), ("⚙️ DeviceDefinition", "slate"), ("🗒️ ActivityDefinition", "slate")], "Adds any PQI domain resource")
s += chain("How Type 3 links narrative and data", [
    (0, None, [("section.text", "teal")]),
    (1, "span id", [('&lt;span id="s3-2-p-3-1-mfr-1"&gt;', "slate")]),
    (0, None, [("section.entry", "blue")]),
    (1, "textLink.htmlid", [("s3-2-p-3-1-mfr-1", "slate")]),
    (1, "reference / textLink.data", [("Organization/org-dp-mfr-1", "purple")]),
])
s += hr() + h3("Step-by-Step Workflow", mb=20)
s += step(1, "Start from the Type 2 document", sp("Set " + code("Composition.category") + " to " + code("type-3") + "."))
s += step(2, "Anchor the narrative",
    sp("Give each passage that discusses a resource a stable " + code("id") + ", e.g. " + code('<span id="s3-2-p-3-1-mfr-1">Sakura Pharma Ltd, Osaka</span>') + ".", 14)
    + tip("Id convention:", code("<section>-<kind>-<n>") + " keeps ids unique within the document and readable in review tools."))
s += step(3, "List the resources each section discusses",
    sp("Add the resources a section discusses to that section's " + code("entry") + ". Resources that no CTD section discusses stay in the Product data section.", 14)
    + table(["Heading", "Typical entries"], [
        ["3.2.S.1 / 3.2.P.1", "SubstanceDefinition; MedicinalProductDefinition, ManufacturedItemDefinition, Ingredient"],
        ["3.2.S.2.1 / 3.2.P.3.1", "Organization"],
        ["3.2.S.2.2 / 3.2.P.3.3", "PlanDefinition (process), DeviceDefinition, ObservationDefinition (CPP / IPC), DocumentReference (flow diagram)"],
        ["3.2.P.3.2", "Medication (batch formula)"],
        ["3.2.S.4.1 / 3.2.P.5.1", "PlanDefinition (specification), ObservationDefinition (tests and acceptance criteria)"],
        ["3.2.S.4.2 / 3.2.P.5.2", "PlanDefinition (analytical procedure)"],
        ["3.2.S.4.4 / 3.2.P.5.4", "DiagnosticReport, Observation, Medication / Substance (batches)"],
        ["3.2.S.5 / 3.2.P.6", "Substance (reference standards)"],
        ["3.2.S.6 / 3.2.P.7", "PackagedProductDefinition"],
        ["3.2.S.7 / 3.2.P.8", "PlanDefinition (stability protocol), DiagnosticReport, Observation, Specimen"],
    ], widths=["28%", None]))
s += step(4, "Link each entry with textLink",
    sp("Add the core " + a("https://hl7.org/fhir/extensions/StructureDefinition-textLink.html", "textLink") + " extension to each " + code("section.entry") + ": " + code("htmlid") + " holds the " + code("id") + " of each span that discusses the resource, and " + code("data") + " repeats the entry's reference. A more specific path can point at one element, e.g. an acceptance criterion inside an " + code("ObservationDefinition") + ". Every entry in a section with authored narrative carries a link, except image DocumentReferences.", 14)
    + pre('''{
  "title": "Manufacturer(s)",
  "code": { "coding": [{ "system": "''' + CS_URL + '''", "code": "3.2.P.3.1" }] },
  "text": {
    "status": "additional",
    "div": "<div xmlns=\\"http://www.w3.org/1999/xhtml\\"><p>The drug product is manufactured by <span id=\\"s3-2-p-3-1-mfr-1\\">Sakura Pharma Ltd, Osaka</span>.</p></div>"
  },
  "entry": [{
    "extension": [{
      "url": "http://hl7.org/fhir/StructureDefinition/textLink",
      "extension": [
        { "url": "htmlid", "valueString": "s3-2-p-3-1-mfr-1" },
        { "url": "data", "valueUri": "Organization/org-dp-mfr-1" }
      ]
    }],
    "reference": "Organization/org-dp-mfr-1"
  }]
}''')
    + tip("Extension status:", "the core " + code("textLink") + " extension (FHIR Extensions Pack 5.3.0) is currently defined for " + code("Narrative") + " only, at most once. FMG has confirmed it will be updated to allow this use (0..*). Until that release, validators may report the extension context on " + code("section.entry") + "."))
s += step(5, "Add the resources and validate",
    sp("Add the resources to the Bundle; each conforms to its PQI profile.", 14)
    + ok("Validate:", "run the Bundle against " + a("StructureDefinition-Bundle-document-type3-pq.html", "BundleDocumentType3Pq", "#15803d") + ". Validation apps also check that every " + code("textLink.htmlid") + " exists in the section narrative."), mb=28)
s += tip("Example:", a("Bundle-bundle-document-collection-pq-sakura-bloom-type3.html", "Sakura Bloom Type 3 collection", "#92400e") + " — 3.2.P.3, 3.2.P.7 and 3.2.R (US) from the ICH Sakura Bloom mock-up. Where a resource is not named in the text, its textLink points to the first heading of the section. All example data is synthetic, drawn from the ICH Sakura Bloom mock-up, the FDA example Quality Overall Summaries and the HL7 FHIR PQI team’s example data; anything none of these provide is marked as synthetic where it appears.")
s += hr() + h3("Checklist", mb=12) + checklist([
    "Every section keeps its authored narrative",
    "Every discussed resource is an entry of the section that discusses it",
    "Every such entry has a " + code("textLink") + " whose " + code("htmlid") + " values exist in the section narrative",
    "Every resource conforms to its PQI profile",
], mb=16)
s += sp("Profiles: " + SD("Bundle-document-type3-pq", "BundleDocumentType3Pq") + ", " + SD("Composition-type3-pq", "CompositionType3Pq") + ". Invariants: the Type 2 set (except " + code("pqi-t2-1") + "), plus " + code("pqi-t3-1") + ".")
s += hr() + whats_next(("build_type4.html", "Type 4 Data-first document", "Let sections that are fully carried by resources drop their authored narrative."))
write("build_type3.md", s)

# ============================================================ build_type4.md
s = comment("PQI TYPE 4 — Build Guide | Target: sponsors with LIMS / MES / QMS data")
s += header_note("📋", "Before you start:", "you need a " + a("build_type3.html", "Type 3 document", "#1e40af") + " and source systems (LIMS, MES, QMS, RIM) that can generate PQI resources.")
s += h3("What is PQI Type 4?")
s += p("In a PQI Type 4 document the resources become the record. Sections whose content is fully expressed by resources drop their authored narrative and keep only " + code("section.entry") + ". Sections that carry argument or justification keep linked narrative, exactly as in Type 3.")
s += cards([
    ("🧬", "Replaced", "Data-first sections", "Manufacturers, specifications, batch analyses, container closure, stability data… carried by resources alone.", "#16a34a"),
    ("✍️", "Kept", "Narrative sections", "Pharmaceutical development, justifications, stability conclusions: authored narrative with textLink.", "#7c3aed"),
    ("🔀", "Mixed", "Both in one section", "E.g. 3.2.P.5.1: the specification table becomes resources, the justification stays as text.", "#d97706"),
])
s += h3("Replaceable headings", mb=12)
s += sp("Only the headings in " + a("ValueSet-vs-ctd-replaceable-pq.html", "vs-ctd-replaceable-pq") + " may omit authored narrative. Their entries must resolve to these resource types (image DocumentReferences are always allowed):", 14)
s += table(["Heading", "Content", "Entries resolve to", "Domain reused", "Invariant"], [
    ["3.2.S.2.1 / 3.2.P.3.1", "Manufacturer(s)", "Organization", a("organizations.html", "Organizations"), code("pqi-t4-org")],
    ["3.2.S.1.1–3.2.S.1.3", "Nomenclature, structure, general properties", "SubstanceDefinition", a("identification.html", "Identification"), code("pqi-t4-gen")],
    ["3.2.P.1", "Description and composition", "MedicinalProductDefinition, ManufacturedItemDefinition, AdministrableProductDefinition, Ingredient", a("composition.html", "Composition"), code("pqi-t4-comp")],
    ["3.2.P.3.2", "Batch formula", "Medication", a("batch_formula.html", "Batch Formula"), code("pqi-t4-bf")],
    ["3.2.S.4.1 / 3.2.P.5.1", "Specification (table part)", "PlanDefinition, ObservationDefinition", a("drug_specification.html", "Drug Specification"), code("pqi-t4-spec")],
    ["3.2.S.4.4 / 3.2.P.5.4", "Batch analyses", "DiagnosticReport, Observation, Medication, Substance", a("batch_anal.html", "Batch Analysis"), code("pqi-t4-ba")],
    ["3.2.S.5 / 3.2.P.6", "Reference standards", "Substance", a("identification.html", "Identification"), code("pqi-t4-rs")],
    ["3.2.S.6 / 3.2.P.7", "Container closure system", "PackagedProductDefinition", a("container.html", "Container Closure System"), code("pqi-t4-ccs")],
    ["3.2.S.7.3 / 3.2.P.8.3", "Stability data", "DiagnosticReport, Observation, Specimen", a("stability.html", "Stability Study"), code("pqi-t4-stab")],
], widths=["17%", "20%", None, "15%", "12%"])
s += callout("These stay narrative", "3.2.P.2 Pharmaceutical development, 3.2.S.4.5 / 3.2.P.5.6 Justification of specification, 3.2.S.7.1 / 3.2.P.8.1 Stability summary and conclusions, and the discussion parts of 3.2.S.2.2, 3.2.P.3.3 and 3.2.P.3.5 follow the Type 3 rules.", "purple", mb=24)
s += hr() + h3("Step-by-Step Workflow", mb=20)
s += step(1, "Start from the Type 3 document", sp("Set " + code("Composition.category") + " to " + code("type-4") + "."))
s += step(2, "Generate the resources from source systems", sp("Generate the resources for each replaceable heading, conforming to the PQI profiles used by the matching domain Bundle."))
s += step(3, "Replace the narrative of replaceable sections",
    sp("In each replaced section, list the resources in " + code("entry") + " and either omit " + code("text") + " or replace it with a <strong>generated</strong> narrative (" + code("status = generated") + ").", 14)
    + compare("Type 1 / 3: authored", "<strong>3.2.P.3.1 Manufacturer(s)</strong><br/>The drug product is manufactured by Sakura Pharma Ltd, Osaka, and packaged by …",
              "Type 4: data-first", '<span style="color:#0891b2;">&lt;section code="3.2.P.3.1"&gt;</span><br/>&nbsp;&nbsp;<span style="color:#9ca3af;">text: absent or generated</span><br/>&nbsp;&nbsp;<span style="color:#16a34a;">entry → Organization/mfr-osaka</span><br/>&nbsp;&nbsp;<span style="color:#16a34a;">entry → Organization/packager</span><br/><span style="color:#0891b2;">&lt;/section&gt;</span>', bad=False)
    + tip("Generated narrative:", "producers SHOULD add it, so that a generic FHIR viewer can still render the document. Receivers SHALL treat the resources, not the generated narrative, as authoritative."))
s += step(4, "Handle mixed sections",
    sp("A section can keep some narrative: in 3.2.P.5.1, the specification table becomes " + code("PlanDefinition") + " + " + code("ObservationDefinition") + " while the justification paragraph stays as narrative with " + code("textLink") + "."))
s += step(5, "Keep the other sections and validate",
    sp("Every other section stays as in Type 3.", 14)
    + ok("Validate:", "run the Bundle against " + a("StructureDefinition-Bundle-document-type4-pq.html", "BundleDocumentType4Pq", "#15803d") + "."), mb=28)
s += hr() + h3("Side by side: 3.2.P.3.1 Manufacturer(s)", mb=12)
s += table(["Type", code("text"), code("entry")], [
    ["<strong>1</strong>", "\"The drug product is manufactured by Sakura Pharma Ltd, Osaka…\"", "none"],
    ["<strong>3</strong>", "Same text, with " + code('<span id="s3-2-p-3-1-mfr-1">'), code("Organization") + ", with " + code("textLink") + " (" + code("htmlid") + " = " + code("s3-2-p-3-1-mfr-1") + ")"],
    ["<strong>4</strong>", "Absent, or generated from the Organizations", code("Organization") + " (one per site)"],
], widths=["10%", None, None], mb=24)
s += tip("Example:", a("Bundle-bundle-document-collection-pq-sakura-bloom-type4.html", "Sakura Bloom Type 4 collection", "#92400e") + " — 3.2.P.3, 3.2.P.7 and 3.2.R (US) from the ICH Sakura Bloom mock-up. 3.2.P.7 is carried by PackagedProductDefinition resources with generated narrative. All example data is synthetic, drawn from the ICH Sakura Bloom mock-up, the FDA example Quality Overall Summaries and the HL7 FHIR PQI team’s example data; anything none of these provide is marked as synthetic where it appears.")
s += h3("Checklist", mb=12) + checklist([
    "Only replaceable headings omit authored narrative",
    "Every replaced section has entries of the allowed types",
    "Generated narrative, where present, has " + code("status = generated"),
    "Sections with argument or justification keep linked narrative",
], mb=16)
s += sp("Profiles: " + SD("Bundle-document-type4-pq", "BundleDocumentType4Pq") + ", " + SD("Composition-type4-pq", "CompositionType4Pq") + ". Invariants: the Type 3 set (narrative required only where it is not replaced), plus " + code("pqi-t4-1") + " and the per-heading invariants above.")
s += hr() + whats_next(("build_validate.html", "Validate and QA", "Validator commands, invariants, and the quality checks for validation apps."))
write("build_type4.md", s)

# ============================================================ build_validate.md
s = comment("PQI BUILD — Validate and QA")
s += header_note("🛡️", "Design principle:", "profiles carry the structural rules, and quality checks live in external validation apps.")
s += h3("Validate a document")
s += p("Validate each document Bundle against the profile of its type, and a collection against " + SD("Bundle-document-collection-pq", "BundleDocumentCollectionPq") + ", with the " + a("https://confluence.hl7.org/display/FHIR/Using+the+FHIR+Validator", "HL7 FHIR Validator") + ".")
s += pre('''java -jar validator_cli.jar my-document.json -version 5.0.0 \\
  -ig hl7.fhir.uv.pharm-quality#current \\
  -profile http://hl7.org/fhir/uv/pharm-quality/StructureDefinition/Bundle-document-type1-pq''')
s += mini([("1️⃣", "Type 1", code("Bundle-document-type1-pq")), ("2️⃣", "Type 2", code("Bundle-document-type2-pq")), ("3️⃣", "Type 3", code("Bundle-document-type3-pq")),
           ("4️⃣", "Type 4", code("Bundle-document-type4-pq")), ("📦", "Collection", code("Bundle-document-collection-pq"))], cols=5, mb=24)
s += hr() + h3("Invariants", mb=6) + sp("Checked by the validator.", 12)
s += table(["Id", "Rule", "Types"], [
    [code("pqi-doc-1"), "The first entry of the document Bundle is the Composition", "1–4"],
    [code("pqi-sec-0"), "Every top-level section is coded from " + a("CodeSystem-ctd-section-pq.html", "CtdSectionPq"), "1–4"],
    [code("pqi-sec-1"), "A sub-section's code sits under its parent's code (3.2.R sub-sections exempt)", "1–4"],
    [code("pqi-sec-2"), "Sibling sections are unique by code, focus and title", "1–4"],
    [code("pqi-gran-1"), "A Module 3.2 Composition has one CTD top-level section, from " + code("vs-ctd-document-root-pq"), "1–4"],
    [code("pqi-foc-1"), code("focus") + " only on repeatable headings", "1–4"],
    [code("pqi-foc-3"), "The focus target is never also an entry of the same section", "1–4"],
    [code("pqi-foc-2"), "Repeated headings each carry a focus", "2–4"],
    [code("pqi-txt-1"), "Every leaf section has narrative", "1–3"],
    [code("pqi-t1-1"), "Section entries reference only image DocumentReferences", "1"],
    [code("pqi-t2-1"), "CTD sections reference only image DocumentReferences", "2"],
    [code("pqi-t3-1"), "Entries of sections with authored narrative carry a " + code("textLink"), "3–4"],
    [code("pqi-t4-1"), "Only replaceable headings may omit authored narrative", "4"],
    [code("pqi-t4-org") + " … " + code("pqi-t4-stab"), "Entries of replaceable headings resolve to the allowed resource types", "4"],
    [code("pqi-gran-2"), "A document collection holds only document Bundles", "collection"],
], widths=["22%", None, "12%"], mb=24)
s += hr() + h3("Quality checks for validation apps", mb=6)
s += sp("These conformance rules cannot be checked reliably with FHIRPath, so validation apps SHALL check them:", 14)
s += cards([
    ("🖼️", "Error", "Images", "Every " + code('<img src="Binary/[id]"/>') + " resolves to a " + code("Binary") + " entry in the same Bundle with an " + code("image/*") + " contentType, described by a DocumentReference listed in the section that shows it.", "#dc2626"),
    ("🔗", "Error", "Broken links", "Every " + code("textLink.htmlid") + " is an " + code("id") + " that exists in the same section's narrative.", "#dc2626"),
    ("🧷", "Warning", "Orphan ids", "Every span " + code("id") + " in a Type 3 or Type 4 narrative is pointed at by an entry.", "#d97706"),
    ("🧾", "Warning", "Heading completeness", "Every heading of the template appears under the document's root heading.", "#d97706"),
    ("🪪", "Warning", "Shared identifiers", "A resource that appears in several documents of a collection has the same identifier in each.", "#d97706"),
], cols=3, mb=24)
s += hr() + h3("Common errors", mb=12)
s += table(["Error", "Fix"], [
    [code("pqi-gran-1") + " fails", "The document spans several level-3 headings: split it, and send the documents together in a collection"],
    [code("pqi-sec-1") + " fails", "A section is nested under the wrong heading: check the code against the " + a("CodeSystem-ctd-section-pq.html", "CtdSectionPq") + " hierarchy"],
    [code("pqi-sec-2") + " fails", "A heading is repeated without a distinct focus (Types 2–4) or title (Type 1)"],
    [code("pqi-t2-1") + " fails", "A resource is referenced from a CTD section in Type 2: move it to the Product data section, or build Type 3"],
    [code("pqi-t3-1") + " fails", "An entry has no " + code("textLink") + ": anchor the passage that discusses it"],
    [code("pqi-t4-1") + " fails", "A non-replaceable section has no authored narrative: restore the narrative"],
], widths=["22%", None], mb=24)
s += hr() + whats_next(None, ("build.html", "Build Overview", "Return to the overview of all four PQI types and how they relate."))
write("build_validate.md", s)
print("ok")
