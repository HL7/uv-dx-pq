"""Package the blank PQI Type 1 templates as one zip (XML and JSON) for the IG Downloads page.

Usage: python3 make_template_zip.py <uv-dx-pq>      (run SUSHI first; reads fsh-generated/resources)
Writes <uv-dx-pq>/input/images/pqi-type1-templates.zip. Needs: pip install "fhir.resources>=8" lxml
"""
import sys, os, json, zipfile, re
from fhir.resources.bundle import Bundle

IG = os.path.abspath(sys.argv[1])
SRC = os.path.join(IG, "fsh-generated", "resources")
OUT = os.path.join(IG, "input", "images", "pqi-type1-templates.zip")
README = """PQI Type 1 templates (ICH M4Q(R1) headings)

Blank FHIR R5 document Bundles conforming to the PQI Type 1 profiles of the HL7 FHIR Pharmaceutical Quality
Information (PQI) IG (http://hl7.org/fhir/uv/pharm-quality). One document per heading:

  2.3          Quality Overall Summary
  3.2.S.1-7    Drug substance (one document per level-3 heading)
  3.2.P.1-8    Drug product (one document per level-3 heading)
  3.2.A.1-3    Appendices
  3.2.R        Regional information (sub-sections use the regulator's own headings)
  3.2 collection   all Module 3.2 templates in one PQI document collection Bundle

Each lowest-level heading is marked "Not started" (narrative status "empty", emptyReason "notstarted").
Before use:
  * replace the bracketed metadata: [Product name], [Applicant], the subject, and the document date
    (the template carries a data-absent-reason extension instead of a date);
  * give each Bundle a new identifier (the template identifiers are placeholders);
  * replace "Not started" with content, set the narrative status to "additional" and remove emptyReason;
  * for several drug substances, copy the 3.2.S documents (and the 2.3.S section) once per substance and
    give each repeat a distinct section title.
"""

def label(bid):
    m = re.match(r"bundle-pqi-type1-template-(.+)", bid).group(1)
    if m == "m23": return "2.3_Quality_Overall_Summary"
    if m == "m32-collection": return "3.2_collection"
    return m.replace("-", ".").upper().replace("3.2.", "3.2.", 1)

files = sorted(f for f in os.listdir(SRC) if f.startswith("Bundle-bundle-pqi-type1-template-"))
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("pqi-type1-templates/README.txt", README)
    for f in files:
        d = json.load(open(os.path.join(SRC, f)))
        lab = label(d["id"])
        if lab.startswith("3.2.") and d["type"] == "document":
            lab += "_" + re.sub(r"[^A-Za-z0-9]+", "_", d["entry"][0]["resource"]["section"][0]["title"]).strip("_")
        name = "PQI_Type1_Template_" + lab
        z.writestr(f"pqi-type1-templates/json/{name}.json", json.dumps(d, ensure_ascii=False, indent=2))
        z.writestr(f"pqi-type1-templates/xml/{name}.xml", Bundle.model_validate(d).model_dump_xml(pretty_print=True))
print(OUT, len(files), "templates")
