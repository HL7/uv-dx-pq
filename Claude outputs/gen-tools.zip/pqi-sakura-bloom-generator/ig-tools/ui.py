"""HTML building blocks matching the ePI IG Build-section styling (inline styles, IG-publisher safe)."""
import html as _h

def esc(s): return _h.escape(s, quote=False)
def code(s): return f'<code style="font-family:monospace; font-size:.8em; color:#0891b2;">{esc(s)}</code>'
def a(href, text, color="#2563eb"): return f'<a href="{href}" style="color:{color}; font-weight:600;">{text}</a>'

def comment(s): return f"<!-- {s} -->\n"
def hr(): return '<hr style="border:none; border-top:1px solid #e5e7eb; margin:28px 0;"/>\n'
def h3(t, id=None, mb=8):
    i = f' id="{id}"' if id else ""
    return f'<h3{i} style="font-size:1.35em; font-weight:700; color:#111827; margin-bottom:{mb}px;">{t}</h3>\n'
def h4(t): return f'<h4 style="font-size:1.05em; font-weight:700; color:#111827; margin:18px 0 8px;">{t}</h4>\n'
def p(t, mb=16): return f'<p style="color:#374151; font-size:.94em; line-height:1.7; margin-bottom:{mb}px;">{t}</p>\n'
def sp(t, mb=10): return f'<p style="font-size:.88em; color:#374151; line-height:1.7; margin-bottom:{mb}px;">{t}</p>\n'
def label(t, mb=8): return f'<div style="margin-bottom:{mb}px;"><span style="font-size:.75em; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#9ca3af;">{t}</span></div>\n'

def header_note(icon, title, text):
    return (f'<div style="background:#eff6ff; border:1px solid #bfdbfe; border-left:4px solid #2563eb; border-radius:8px; padding:12px 18px; margin-bottom:24px; font-size:.85em; color:#1e40af; display:flex; gap:10px; align-items:flex-start;">\n'
            f'  <span style="flex-shrink:0; font-size:1em;">{icon}</span>\n  <span><strong>{title}</strong> {text}</span>\n</div>\n')

BADGE = {"blue": ("#eff6ff", "#bfdbfe", "#1d4ed8"), "teal": ("#f0fdfa", "#99f6e4", "#0f766e"), "purple": ("#faf5ff", "#e9d5ff", "#7e22ce"),
         "amber": ("#fffbeb", "#fde68a", "#b45309"), "green": ("#f0fdf4", "#bbf7d0", "#15803d"), "rose": ("#fff1f2", "#fecdd3", "#be123c"),
         "slate": ("#f8fafc", "#e2e8f0", "#334155")}
def badges(items, title="You will create these FHIR resources"):
    out = label(title) + '<div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:28px;">\n'
    for txt, col in items:
        bg, bd, fg = BADGE[col]
        out += f'  <span style="background:{bg}; border:1px solid {bd}; color:{fg}; font-size:.78em; font-weight:600; padding:4px 12px; border-radius:99px;">{txt}</span>\n'
    return out + "</div>\n"

def chip(txt, col):
    bg, bd, fg = BADGE[col]
    return f'<span style="background:{bg}; border:1px solid {bd}; color:{fg}; padding:5px 12px; border-radius:6px; font-weight:600;">{txt}</span>'

def chain(title, rows):
    """rows: list of (depth, verb or None, [(text,color),...])"""
    out = (f'<div style="background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px; padding:18px 20px; margin-bottom:28px;">\n'
           f'  <div style="font-size:.72em; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#9ca3af; margin-bottom:12px;">{title}</div>\n  <div style="font-size:.8em;">\n')
    for depth, verb, chips in rows:
        v = f'<span style="color:#6b7280; font-size:.85em; font-style:italic; margin-right:8px;">{verb}</span>' if verb else ""
        cs = " ".join(chip(t, c) for t, c in chips)
        if depth == 0:
            out += f'    <div style="margin-bottom:8px;">{v}{cs}</div>\n'
        else:
            out += f'    <div style="border-left:2px solid #e5e7eb; margin-left:{14 + 24 * (depth - 1)}px; padding-left:14px; margin-bottom:8px; line-height:2.4;">{v}{cs}</div>\n'
    return out + "  </div>\n</div>\n"

def step(n, title, body, mb=20):
    return (f'{comment(f"STEP {n}")}<div style="display:flex; gap:16px; margin-bottom:{mb}px; align-items:flex-start;">\n'
            f'  <div style="flex-shrink:0; width:36px; height:36px; border-radius:50%; background:#003087; color:#fff; display:flex; align-items:center; justify-content:center; font-size:.85em; font-weight:700; margin-top:2px;">{n}</div>\n'
            f'  <div style="flex:1; background:#fff; border:1px solid #e5e7eb; border-radius:8px; overflow:hidden;">\n'
            f'    <div style="padding:14px 20px 10px; border-bottom:1px solid #e5e7eb; background:#f9fafb;"><div style="font-weight:700; color:#111827; font-size:.97em;">{title}</div></div>\n'
            f'    <div style="padding:14px 20px;">\n{body}    </div>\n  </div>\n</div>\n')

def tip(title, text, mb=10):
    return (f'<div style="background:#fffbeb; border:1px solid #fde68a; border-left:3px solid #d97706; border-radius:6px; padding:10px 14px; margin-bottom:{mb}px; font-size:.82em; color:#78350f; display:flex; gap:10px; align-items:flex-start;">\n'
            f'  <span style="flex-shrink:0;">💡</span>\n  <span><strong>{title}</strong> {text}</span>\n</div>\n')
def ok(title, text, mb=10):
    return (f'<div style="background:#dcfce7; border:1px solid #bbf7d0; border-left:3px solid #16a34a; border-radius:6px; padding:10px 14px; margin-bottom:{mb}px; font-size:.82em; color:#14532d; display:flex; gap:10px; align-items:flex-start;">\n'
            f'  <span style="flex-shrink:0;">✅</span>\n  <span><strong>{title}</strong> {text}</span>\n</div>\n')
def warn(title, text, mb=10):
    return (f'<div style="background:#fef2f2; border:1px solid #fecaca; border-left:3px solid #dc2626; border-radius:6px; padding:10px 14px; margin-bottom:{mb}px; font-size:.82em; color:#7f1d1d; display:flex; gap:10px; align-items:flex-start;">\n'
            f'  <span style="flex-shrink:0;">⚠️</span>\n  <span><strong>{title}</strong> {text}</span>\n</div>\n')

CALL = {"blue": ("#eff6ff", "#bfdbfe", "#2563eb", "#1d4ed8", "#1e40af"), "yellow": ("#fefce8", "#fef08a", "#eab308", "#854d0e", "#713f12"),
        "green": ("#f0fdf4", "#bbf7d0", "#16a34a", "#15803d", "#14532d"), "purple": ("#faf5ff", "#e9d5ff", "#7c3aed", "#6d28d9", "#4c1d95")}
def callout(title, text, col="blue", mb=16):
    bg, bd, bl, tc, fc = CALL[col]
    return (f'<div style="background:{bg}; border:1px solid {bd}; border-left:4px solid {bl}; border-radius:8px; padding:14px 18px; margin-bottom:{mb}px;">\n'
            f'  <div style="font-size:.72em; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:{tc}; margin-bottom:6px;">{title}</div>\n'
            f'  <div style="font-size:.88em; color:{fc}; line-height:1.7; margin:0;">{text}</div>\n</div>\n')

def table(headers, rows, widths=None, mb=14, small=True):
    fs = ".84em" if small else "14px"
    out = f'<table style="width:100%; border-collapse:collapse; font-size:{fs}; margin-bottom:{mb}px;">\n  <thead><tr style="background:#003087; color:#fff;">'
    for i, h in enumerate(headers):
        w = f" width:{widths[i]};" if widths and widths[i] else ""
        out += f'<th style="padding:9px 12px; border:1px solid #d0d0d0; text-align:left;{w}">{h}</th>'
    out += "</tr></thead>\n  <tbody>\n"
    for i, r in enumerate(rows):
        bg = ' style="background:#f9fafb;"' if i % 2 else ""
        out += f"    <tr{bg}>" + "".join(f'<td style="padding:9px 12px; border:1px solid #d0d0d0; vertical-align:top;">{c}</td>' for c in r) + "</tr>\n"
    return out + "  </tbody>\n</table>\n"

def pre(s, mb=14):
    return (f'<pre style="background:#0f172a; color:#e2e8f0; border-radius:8px; padding:14px 16px; font-size:.76em; line-height:1.6; overflow-x:auto; margin-bottom:{mb}px;"><code>'
            f"{esc(s)}</code></pre>\n")

def cards(items, cols=3, mb=14):
    """items: (icon, kicker, title, text, border-color or None)"""
    out = f'<div style="display:grid; grid-template-columns:repeat({cols},1fr); gap:12px; margin-bottom:{mb}px;">\n'
    for icon, kick, title, text, color in items:
        top = f" border-top:3px solid {color};" if color else ""
        out += (f'  <div style="background:#fff; border:1px solid #e5e7eb;{top} border-radius:8px; padding:16px 18px;">\n'
                + (f'    <div style="font-size:1.3em; margin-bottom:6px;">{icon}</div>\n' if icon else "")
                + (f'    <div style="font-size:.72em; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#9ca3af; margin-bottom:4px;">{kick}</div>\n' if kick else "")
                + f'    <div style="font-weight:700; color:#111827; margin-bottom:6px; font-size:.95em;">{title}</div>\n'
                f'    <div style="font-size:.84em; color:#6b7280; line-height:1.6;">{text}</div>\n  </div>\n')
    return out + "</div>\n"

def mini(items, cols=3, mb=14):
    out = f'<div style="display:grid; grid-template-columns:repeat({cols},1fr); gap:10px; margin-bottom:{mb}px;">\n'
    for icon, title, text in items:
        out += (f'  <div style="background:#f9fafb; border:1px solid #e5e7eb; border-radius:6px; padding:12px 14px; text-align:center;">\n'
                f'    <div style="font-size:1.3em; margin-bottom:6px;">{icon}</div>\n'
                f'    <div style="font-size:.78em; font-weight:700; color:#111827; margin-bottom:4px;">{title}</div>\n'
                f'    <div style="font-size:.76em; color:#6b7280;">{text}</div>\n  </div>\n')
    return out + "</div>\n"

def compare(left_title, left_html, right_title, right_html, label_text=None, bad=True, mb=14):
    lt = (("#fecaca", "#fef2f2", "#b91c1c", "⚠ ") if bad else ("#e5e7eb", "#f9fafb", "#374151", ""))
    out = (f'<div style="font-size:.78em; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#9ca3af; margin-bottom:6px;">{label_text}</div>\n' if label_text else "")
    out += (f'<div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:{mb}px;">\n'
            f'  <div style="border:1px solid {lt[0]}; border-radius:8px; overflow:hidden;">\n'
            f'    <div style="padding:7px 12px; background:{lt[1]}; border-bottom:1px solid {lt[0]};"><span style="font-size:.7em; font-weight:700; text-transform:uppercase; color:{lt[2]};">{lt[3]}{left_title}</span></div>\n'
            f'    <div style="padding:10px 12px; font-size:.8em; color:#374151; line-height:1.8;">{left_html}</div>\n  </div>\n'
            f'  <div style="border:1px solid #bbf7d0; border-radius:8px; overflow:hidden;">\n'
            f'    <div style="padding:7px 12px; background:#f0fdf4; border-bottom:1px solid #bbf7d0;"><span style="font-size:.7em; font-weight:700; text-transform:uppercase; color:#15803d;">✓ {right_title}</span></div>\n'
            f'    <div style="padding:10px 12px; font-size:.76em; font-family:ui-monospace,\'SF Mono\',monospace; color:#374151; line-height:1.9;">{right_html}</div>\n  </div>\n</div>\n')
    return out

def checklist(items, mb=8):
    out = f'<div style="background:#fff; border:1px solid #e5e7eb; border-radius:8px; padding:14px 20px; margin-bottom:{mb}px;">\n'
    for it in items:
        out += f'  <div style="font-size:.88em; color:#374151; line-height:1.6; padding:5px 0; border-bottom:1px dashed #f1f5f9;"><span style="color:#16a34a; font-weight:700; margin-right:8px;">☐</span>{it}</div>\n'
    return out + "</div>\n"

def whats_next(nxt=None, ref=("build.html", "Build Overview", "Return to the overview of all four PQI types and how they relate.")):
    out = h3("What's next?", mb=12).replace("1.35em", "1.1em") + '<div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">\n'
    if nxt:
        href, title, text = nxt
        out += (f'  <a href="{href}" style="text-decoration:none; background:#fff; border:1px solid #bfdbfe; border-left:4px solid #2563eb; border-radius:8px; padding:16px 20px; display:block;">\n'
                f'    <div style="font-size:.72em; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#2563eb; margin-bottom:4px;">Next →</div>\n'
                f'    <div style="font-weight:700; color:#111827; margin-bottom:4px;">{title}</div>\n    <div style="font-size:.82em; color:#6b7280;">{text}</div>\n  </a>\n')
    href, title, text = ref
    out += (f'  <a href="{href}" style="text-decoration:none; background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px; padding:16px 20px; display:block;">\n'
            f'    <div style="font-size:.72em; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#6b7280; margin-bottom:4px;">Reference</div>\n'
            f'    <div style="font-weight:700; color:#111827; margin-bottom:4px;">{title}</div>\n    <div style="font-size:.82em; color:#6b7280;">{text}</div>\n  </a>\n')
    return out + "</div>\n"

def ul(items): return '<ul style="font-size:.88em; color:#374151; line-height:1.8; margin:0 0 10px 0; padding-left:20px;">' + "".join(f"<li>{i}</li>" for i in items) + "</ul>\n"
