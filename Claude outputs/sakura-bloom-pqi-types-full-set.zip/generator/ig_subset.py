"""Write the in-IG Sakura Bloom examples: one collection per PQI type holding 3.2.P.3, 3.2.P.7 and 3.2.R (US).
Usage: python3 ig_subset.py <uv-dx-pq>/input/examples   (run run_pqi_types.py first)"""
import sys, os, json
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "fhir", "pqi-types")
KEEP = ("3-2-p-3", "3-2-p-7", "3-2-r-us")
out = sys.argv[1]
for t in (1, 2, 3, 4):
    b = json.load(open(f"{SRC}/type{t}/bundle-document-collection-pq-sakura-bloom-m32-type{t}.json"))
    b["entry"] = [e for e in b["entry"] if e["resource"]["id"].split("sakura-bloom-m32-")[1] in KEEP]
    b["id"] = f"bundle-document-collection-pq-sakura-bloom-type{t}"
    b["identifier"]["value"] = b["identifier"]["value"][:-4] + f"{t:04d}"
    p = os.path.join(out, b["id"] + ".json")
    json.dump(b, open(p, "w"), ensure_ascii=False, indent=2)
    print(p, os.path.getsize(p) // 1024, "KB", [e["resource"]["id"] for e in b["entry"]])
