"""Build the PQI Type 1-4 examples from the extract.  Usage: python3 run_pqi_types.py [extract.json]   (OUT=<dir>)"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
from lib import *
import part1_core, part2_specs, part3_process_data, pqi_types
HERE = os.path.dirname(os.path.abspath(__file__))
S = Source(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "source", "sakura-bloom-r2-extract.json"))
part1_core.build(S); part2_specs.build(S); part3_process_data.build(S); finalize()
OUT = os.environ.get("OUT", os.path.join(HERE, "..", "fhir", "pqi-types"))
out, unmapped = pqi_types.build(S, OUT)
print("unmapped pages:", len(unmapped))
for u in unmapped: print("  -", u[:150])
