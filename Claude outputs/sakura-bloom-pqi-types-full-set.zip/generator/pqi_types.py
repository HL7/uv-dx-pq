"""PQI maturity Types 1-4 from the Sakura Bloom R2 extract.

Places each M4Q(R2) mock-up page under its ICH M4Q(R1) heading (following the ICH "Mapping R1 versus R2"
document, 12 January 2026), then builds:
  * one Module 2.3 QOS document, and
  * one Module 3.2 document per level-3 heading (plus 3.2.R for the US), packaged in a document collection,
at each PQI type (1 = structured document, 2 = + product data, 3 = linked document, 4 = data-first document).

Usage (after build.py has populated R):  pqi_types.build(S, outdir, types=(1,2,3,4))
"""
import os, re, json, copy, base64, zlib, struct, uuid
import xml.etree.ElementTree as ET
from collections import OrderedDict
from lib import *
from part4_docs_bundles import section_entries

PQ_CS = PQ + "/CodeSystem/"
CTD = PQ_CS + "ctd-section-pq"
XH = "http://www.w3.org/1999/xhtml"
ET.register_namespace("", XH)
DATE = "2025-09-15"
TS = "2026-11-21T00:00:00Z"
NS = uuid.UUID("2b8f0b8e-0a43-4a0f-8a5e-7c5d1f0e9a21")
NOT_PROVIDED = "Not provided in the Sakura Bloom mock-up."
SEE_PARENT = "Not provided separately in the Sakura Bloom mock-up; see the parent section."

# ----------------------------------------------------------------------------- M4Q(R1) headings
H = [("2.3", "Quality Overall Summary"), ("2.3.INTRO", "Introduction"), ("2.3.S", "Drug Substance"),
     ("2.3.S.1", "General Information"), ("2.3.S.2", "Manufacture"), ("2.3.S.3", "Characterisation"), ("2.3.S.4", "Control of Drug Substance"),
     ("2.3.S.5", "Reference Standards or Materials"), ("2.3.S.6", "Container Closure System"), ("2.3.S.7", "Stability"),
     ("2.3.P", "Drug Product"), ("2.3.P.1", "Description and Composition of the Drug Product"), ("2.3.P.2", "Pharmaceutical Development"),
     ("2.3.P.3", "Manufacture"), ("2.3.P.4", "Control of Excipients"), ("2.3.P.5", "Control of Drug Product"), ("2.3.P.6", "Reference Standards or Materials"),
     ("2.3.P.7", "Container Closure System"), ("2.3.P.8", "Stability"), ("2.3.A", "Appendices"), ("2.3.A.1", "Facilities and Equipment"),
     ("2.3.A.2", "Adventitious Agents Safety Evaluation"), ("2.3.A.3", "Excipients"), ("2.3.R", "Regional Information"),
     ("3.2.S.1", "General Information"), ("3.2.S.1.1", "Nomenclature"), ("3.2.S.1.2", "Structure"), ("3.2.S.1.3", "General Properties"),
     ("3.2.S.2", "Manufacture"), ("3.2.S.2.1", "Manufacturer(s)"), ("3.2.S.2.2", "Description of Manufacturing Process and Process Controls"),
     ("3.2.S.2.3", "Control of Materials"), ("3.2.S.2.4", "Controls of Critical Steps and Intermediates"), ("3.2.S.2.5", "Process Validation and/or Evaluation"),
     ("3.2.S.2.6", "Manufacturing Process Development"), ("3.2.S.3", "Characterisation"), ("3.2.S.3.1", "Elucidation of Structure and other Characteristics"),
     ("3.2.S.3.2", "Impurities"), ("3.2.S.4", "Control of Drug Substance"), ("3.2.S.4.1", "Specification"), ("3.2.S.4.2", "Analytical Procedures"),
     ("3.2.S.4.3", "Validation of Analytical Procedures"), ("3.2.S.4.4", "Batch Analyses"), ("3.2.S.4.5", "Justification of Specification"),
     ("3.2.S.5", "Reference Standards or Materials"), ("3.2.S.6", "Container Closure System"), ("3.2.S.7", "Stability"),
     ("3.2.S.7.1", "Stability Summary and Conclusions"), ("3.2.S.7.2", "Post-approval Stability Protocol and Stability Commitment"), ("3.2.S.7.3", "Stability Data"),
     ("3.2.P.1", "Description and Composition of the Drug Product"), ("3.2.P.2", "Pharmaceutical Development"), ("3.2.P.2.1", "Components of the Drug Product"),
     ("3.2.P.2.1.1", "Drug Substance"), ("3.2.P.2.1.2", "Excipients"), ("3.2.P.2.2", "Drug Product"), ("3.2.P.2.2.1", "Formulation Development"),
     ("3.2.P.2.2.2", "Overages"), ("3.2.P.2.2.3", "Physicochemical and Biological Properties"), ("3.2.P.2.3", "Manufacturing Process Development"),
     ("3.2.P.2.4", "Container Closure System"), ("3.2.P.2.5", "Microbiological Attributes"), ("3.2.P.2.6", "Compatibility"), ("3.2.P.3", "Manufacture"),
     ("3.2.P.3.1", "Manufacturer(s)"), ("3.2.P.3.2", "Batch Formula"), ("3.2.P.3.3", "Description of Manufacturing Process and Process Controls"),
     ("3.2.P.3.4", "Controls of Critical Steps and Intermediates"), ("3.2.P.3.5", "Process Validation and/or Evaluation"), ("3.2.P.4", "Control of Excipients"),
     ("3.2.P.4.1", "Specifications"), ("3.2.P.4.2", "Analytical Procedures"), ("3.2.P.4.3", "Validation of Analytical Procedures"),
     ("3.2.P.4.4", "Justification of Specifications"), ("3.2.P.4.5", "Excipients of Human or Animal Origin"), ("3.2.P.4.6", "Novel Excipients"),
     ("3.2.P.5", "Control of Drug Product"), ("3.2.P.5.1", "Specification(s)"), ("3.2.P.5.2", "Analytical Procedures"), ("3.2.P.5.3", "Validation of Analytical Procedures"),
     ("3.2.P.5.4", "Batch Analyses"), ("3.2.P.5.5", "Characterisation of Impurities"), ("3.2.P.5.6", "Justification of Specification(s)"),
     ("3.2.P.6", "Reference Standards or Materials"), ("3.2.P.7", "Container Closure System"), ("3.2.P.8", "Stability"), ("3.2.P.8.1", "Stability Summary and Conclusion"),
     ("3.2.P.8.2", "Post-approval Stability Protocol and Stability Commitment"), ("3.2.P.8.3", "Stability Data"),
     ("3.2.A.1", "Facilities and Equipment"), ("3.2.A.2", "Adventitious Agents Safety Evaluation"), ("3.2.A.3", "Excipients"), ("3.2.R", "Regional Information")]
CODES = [c for c, _ in H]; DISP = dict(H)
def parent(c):
    best = None
    for p in CODES:
        if p != c and c.startswith(p + ".") and (best is None or len(p) > len(best)): best = p
    return best
def children(c): return [x for x in CODES if parent(x) == c]
ROOTS = [c for c in CODES if c.startswith("3.2.") and c.count(".") == 3] + ["3.2.R"]
REPLACEABLE = {"3.2.S.2.1": ("Organization",), "3.2.P.3.1": ("Organization",), "3.2.S.1.1": ("SubstanceDefinition",),
               "3.2.S.1.2": ("SubstanceDefinition",), "3.2.S.1.3": ("SubstanceDefinition",),
               "3.2.P.1": ("MedicinalProductDefinition", "ManufacturedItemDefinition", "AdministrableProductDefinition", "Ingredient"),
               "3.2.P.3.2": ("Medication",), "3.2.S.4.1": ("PlanDefinition", "ObservationDefinition"), "3.2.P.5.1": ("PlanDefinition", "ObservationDefinition"),
               "3.2.S.4.4": ("DiagnosticReport", "Observation", "Medication", "Substance"), "3.2.P.5.4": ("DiagnosticReport", "Observation", "Medication", "Substance"),
               "3.2.S.5": ("Substance",), "3.2.P.6": ("Substance",), "3.2.S.6": ("PackagedProductDefinition",), "3.2.P.7": ("PackagedProductDefinition",),
               "3.2.S.7.3": ("DiagnosticReport", "Observation", "Specimen"), "3.2.P.8.3": ("DiagnosticReport", "Observation", "Specimen")}

# ----------------------------------------------------------------------------- R2 page -> R1 heading
def norm(part):
    s = part.strip()
    s = re.sub(r"^(\d\.\d(?:\.\d)?)\.\s+", r"\1.", s)        # "2.3.3. AP" -> "2.3.3.AP"
    s = re.sub(r"^(2\.3\.4)\s+(RS|AP)\b", r"\1.\2", s)       # "2.3.4 RS"  -> "2.3.4.RS"
    return s
R2RE = re.compile(r"^(2\.3(?:\.\d(?:\.\d)*)?(?:\.[A-Z]{2}(?:\.[A-Z])?(?:\.\d+)?)?|3\.2\.[A-Z]{2}(?:\.[A-Z](?:\.\d+)?)?)\.?(?:\s|$|\[|\()")
def r2code(short):
    for part in reversed(short.split(" / ")):
        m = R2RE.match(norm(part))
        if m: return m.group(1)
    return None

def material(short):
    s = short
    if re.search(r"Coating|Premix|premix", s): return "PREMIX"
    if re.search(r"\[CP-[48]\]|\(CP-[48]\)|SM[12]\)|\bSM\b", s) and "Sakura Bloom" not in s: return "SM"
    if re.search(r"\[CP-[67]\]|\(CP-[67]\)|IM[12]\)", s): return "SI"
    if re.search(r"Sakura [Bb]loom|\(Sakura Bloom|20 mg", s): return "DP"
    return "DS"

def targets(page):
    """Return (r1 codes in Module 3.2 documents, r1 codes in the Module 2.3 document) for one source page."""
    short, title = page["short"], page["short"].split(" / ")[-1].strip()
    code = r2code(short) or ""
    m23 = short.startswith("Module 2.3")
    layer = "DSJ" if code.startswith("2.3.4") else ("CORE" if code.startswith("2.3.3") else ("DATA" if code.startswith("3.2") else "M2"))
    area = None
    m = re.match(r"^(?:2\.3\.\d|2\.3|3\.2)\.([A-Z]{2})(?:\.([A-Z]))?(?:\.(\d+))?", code)
    if m: area, sub, num = m.group(1), m.group(2), m.group(3)
    else: sub = num = None
    mat = material(short)
    t32, t23 = [], []
    us = "USA" in title or "US addendum" in title
    china = "China" in title
    if code.startswith("2.3.1"): t23 = ["2.3.INTRO"]
    elif code.startswith("2.3.2"): t23 = ["2.3.P.2"]
    elif code.startswith("2.3.5"):
        if "Post-approval Quality Commitments" in title: t32, t23 = ["3.2.S.7.2", "3.2.P.8.2"], ["2.3.P.8"]
    elif area == "FA":
        if us: t32, t23 = ["3.2.R"], ["2.3.R"]
        elif layer == "DATA": t32 = ["3.2.A.1"]
        else: t32, t23 = ["3.2.S.2.1", "3.2.P.3.1"], ["2.3.S.2", "2.3.P.3"]
    elif area == "DS":
        if sub == "D": t32, t23 = ({"CORE": ["3.2.S.1"], "DSJ": ["3.2.S.3.1"], "DATA": ["3.2.S.3.1"]}[layer], {"CORE": ["2.3.S.1"], "DSJ": ["2.3.S.3"]}.get(layer, []))
        elif sub == "M": t32, t23 = ({"CORE": ["3.2.S.2.2"], "DSJ": ["3.2.S.2.6"], "DATA": ["3.2.S.2.2"]}[layer], ["2.3.S.2"] if layer != "DATA" else [])
        elif sub == "C":
            if layer == "DATA":
                t32 = ["3.2.S.4.4"] if title.startswith("3.2.DS.C") else ["3.2.S.3.2"]
            else: t32, t23 = ({"CORE": ["3.2.S.4.1"], "DSJ": ["3.2.S.4.5"]}[layer], ["2.3.S.4"])
        elif sub == "S": t32, t23 = ({"CORE": ["3.2.S.6"], "DSJ": ["3.2.S.7.1"], "DATA": ["3.2.S.7.3"]}[layer], ["2.3.S.7"] if layer != "DATA" else [])
    elif area == "IM": t32 = ["3.2.S.3.2"]
    elif area in ("SM", "RM"): t32, t23 = ["3.2.S.2.3"], (["2.3.S.2"] if m23 else [])
    elif area == "SI": t32, t23 = ["3.2.S.2.4"], (["2.3.S.2"] if m23 else [])
    elif area == "RS": t32, t23 = ["3.2.S.5"], (["2.3.S.5"] if m23 else [])
    elif area == "AP":
        val = layer == "DSJ" or title.startswith("VR_") or "Method validation" in title
        if mat == "DP": t32, t23 = ["3.2.P.5.3" if val else "3.2.P.5.2"], ["2.3.P.5"]
        elif mat == "PREMIX": t32, t23 = ["3.2.P.4.3" if val else "3.2.P.4.2"], ["2.3.P.4"]
        elif mat == "SM": t32, t23 = ["3.2.S.2.3"], ["2.3.S.2"]
        elif mat == "SI": t32, t23 = ["3.2.S.2.4"], ["2.3.S.2"]
        else: t32, t23 = ["3.2.S.4.3" if val else "3.2.S.4.2"], ["2.3.S.4"]
    elif area == "DP":
        if us: t32, t23 = ["3.2.R"], ["2.3.R"]
        elif sub == "D": t32, t23 = ({"CORE": ["3.2.P.1"], "DSJ": ["3.2.P.2"], "DATA": ["3.2.P.2"]}[layer], {"CORE": ["2.3.P.1"], "DSJ": ["2.3.P.2"]}.get(layer, []))
        elif sub == "M": t32, t23 = ({"CORE": ["3.2.P.3.3"], "DSJ": ["3.2.P.2.3"], "DATA": ["3.2.P.3.3"]}[layer], ["2.3.P.3"] if layer != "DATA" else [])
        elif sub == "C":
            t32 = {"CORE": ["3.2.P.5.1"], "DSJ": ["3.2.P.5.6"], "DATA": ["3.2.P.5.4"]}[layer]; t23 = ["2.3.P.5"] if layer != "DATA" else []
        elif sub == "S":
            if layer == "DATA": t32 = ["3.2.P.8.3"] if "stability report" in title.lower() else ["3.2.P.7"]
            else: t32, t23 = ["3.2.P.8.1"], ["2.3.P.8"]
    elif area == "EX":
        if china: t23 = ["2.3.R"]                       # regional (China): only the US is modelled in Module 3.2
        elif "Novel" in title: t32, t23 = ["3.2.P.4.6"], ["2.3.P.4"]
        elif layer == "DSJ": t32, t23 = ["3.2.P.4.4"], ["2.3.P.4"]
        else: t32, t23 = ["3.2.P.4.1"], (["2.3.P.4"] if m23 else [])
    if not m23: t23 = []
    return t32, t23

LINK_JUNK = re.compile(r"^\s*(?:\[[^\]]*\]\s*)*#[0-9a-f]{12}\]\s*$", re.M)
def clean(text):
    """Drop page-link residue such as '[FCT][20 mg] #ec38db365232]' left by the Notion export."""
    return LINK_JUNK.sub("", re.sub(r"→ \[PAGE:[^\]]*\]", "", text))
def trivial(page):
    return len(clean(page["text"]).strip()) < 20

# ----------------------------------------------------------------------------- XHTML helpers
def parse_div(div):
    return ET.fromstring(div)

def div_str(el):
    return ET.tostring(el, encoding="unicode")

IMG_RE = re.compile(r"\[IMAGE:\s*attachment:([0-9a-f\-]+):([^\]]+)\]")

def png_placeholder(w=320, h=48):
    """A tiny grey PNG used as a clearly labelled placeholder (the extract has no image bytes)."""
    raw = b"".join(b"\x00" + bytes([0xE5, 0xE7, 0xEB]) * w for _ in range(h))
    def chunk(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
PNG = base64.b64encode(png_placeholder()).decode()

def page_body(page, images):
    """Page content as a list of XHTML elements (page title heading first). Images -> <img src="Binary/..">."""
    text = clean(page["text"])
    def repl(m):
        iid = "img-" + m.group(1)[:8]
        images.setdefault(iid, {"name": m.group(2), "page": page["short"].split(" / ")[-1].strip()})
        return f"@@IMG:{iid}@@"
    text = IMG_RE.sub(repl, text)
    x = md_to_xhtml(text)["div"]
    el = parse_div(x)
    out = [ET.Element(f"{{{XH}}}h3")]
    out[0].text = page["short"].split(" / ")[-1].strip()
    prev_text = ""
    for c in list(el):
        t = "".join(c.itertext())
        m = re.fullmatch(r"\s*•?\s*@@IMG:([a-z0-9\-]+)@@\s*", t)
        if m:
            iid = m.group(1)
            images[iid]["caption"] = images[iid].get("caption") or (prev_text if re.match(r"^(Figure|Scheme|Table)\b", prev_text) else images[iid]["name"])
            p = ET.Element(f"{{{XH}}}p"); img = ET.SubElement(p, f"{{{XH}}}img", {"src": f"Binary/{iid}", "alt": images[iid]["caption"][:120]})
            out.append(p); continue
        if "@@IMG:" in t:   # image token inside other text: drop the token, keep the text
            for e in c.iter():
                if e.text: e.text = re.sub(r"@@IMG:[a-z0-9\-]+@@", "", e.text)
                if e.tail: e.tail = re.sub(r"@@IMG:[a-z0-9\-]+@@", "", e.tail)
        out.append(c); prev_text = t.strip()
    return out

def make_div(elements, fallback=None):
    d = ET.Element(f"{{{XH}}}div")
    for e in elements: d.append(e)
    if not len(d):
        p = ET.SubElement(d, f"{{{XH}}}p"); p.text = fallback or NOT_PROVIDED
    return d

# ----------------------------------------------------------------------------- names for textLink spans
def names_of(r):
    t = r["resourceType"]; n = []
    g = lambda *ks: [r.get(k) for k in ks if isinstance(r.get(k), str)]
    n += g("title", "name", "description")
    if t == "Organization": n += r.get("alias", [])
    if t == "SubstanceDefinition": n += [x.get("name") for x in r.get("name", [])] + [i.get("value") for i in r.get("identifier", [])]
    if t == "MedicinalProductDefinition": n += [x.get("productName") for x in r.get("name", [])]
    if t in ("Medication",): n += [r.get("batch", {}).get("lotNumber"), r.get("code", {}).get("text")]
    if t == "Substance": n += [i.get("value") for i in r.get("identifier", [])] + [r.get("code", {}).get("concept", {}).get("text")]
    if t in ("DiagnosticReport", "ObservationDefinition", "Observation"): n += [r.get("code", {}).get("text")]
    if t == "DeviceDefinition": n += [x.get("name") for x in r.get("deviceName", [])]
    if t == "DocumentReference": n += [c.get("attachment", {}).get("title") for c in r.get("content", [])]
    if t == "Ingredient":
        s = r.get("substance", {}).get("code", {})
        n += [s.get("concept", {}).get("text"), s.get("reference", {}).get("display")]
    if t == "PackagedProductDefinition": n += [x for x in [r.get("name")] if x]
    out = []
    for x in n:
        if isinstance(x, str) and len(x.strip()) >= 3 and x.strip() not in out: out.append(x.strip())
    return sorted(out, key=len, reverse=True)

def wrap_first(div, needle, idv):
    """Wrap the first occurrence of needle (case-insensitive) in a text node with <span id>. Returns True if wrapped."""
    pat = re.compile(re.escape(needle), re.I)
    parents = {c: p for p in div.iter() for c in p}
    for el in div.iter():
        if el.tag == f"{{{XH}}}span" and el.get("id"): continue
        if el.text and (m := pat.search(el.text)):
            sp = ET.Element(f"{{{XH}}}span", {"id": idv}); sp.text = m.group(0); sp.tail = el.text[m.end():]
            el.text = el.text[:m.start()]; el.insert(0, sp); return True
        for i, ch in enumerate(list(el)):
            if ch.tail and not (ch.tag == f"{{{XH}}}span" and False) and (m := pat.search(ch.tail)):
                sp = ET.Element(f"{{{XH}}}span", {"id": idv}); sp.text = m.group(0); sp.tail = ch.tail[m.end():]
                ch.tail = ch.tail[:m.start()]; el.insert(i + 1, sp); return True
    return False

# ----------------------------------------------------------------------------- document assembly
def uid(s): return "urn:uuid:" + str(uuid.uuid5(NS, s))
def full(k): return f"{BASE}/{k}"

class Doc:
    def __init__(self, did, doc_type, top_codes, subject_ds):
        self.did, self.doc_type, self.top, self.subject_ds = did, doc_type, top_codes, subject_ds
        self.content = OrderedDict()   # r1 code -> list of elements
        self.entries = OrderedDict()   # r1 code -> list of resource keys
        self.images = OrderedDict()
        self.regional = []             # (title, elements, entries) for 3.2.R sub-sections

def collect(S):
    m23 = Doc("sakura-bloom-m23", "m2-3-qos", ["2.3"], False)
    docs32 = OrderedDict((r, Doc("sakura-bloom-m32-" + r.lower().replace(".", "-") + ("-us" if r == "3.2.R" else ""), "m3-2-quality", [r], r.startswith("3.2.S"))) for r in ROOTS)
    unmapped = []
    for p in S.pages:
        if not (p["short"].startswith("Module 2.3") or p["short"].startswith("Module 3.2")) or trivial(p): continue
        t32, t23 = targets(p)
        if not t32 and not t23: unmapped.append(p["short"]); continue
        ents = section_entries(p["short"])
        for code in t23:
            m23.content.setdefault(code, []).extend(page_body(p, m23.images)); m23.entries.setdefault(code, []).extend(ents)
        for code in t32:
            root = next(r for r in ROOTS if code == r or code.startswith(r + "."))
            d = docs32[root]
            if code == "3.2.R":
                d.regional.append((p["short"].split(" / ")[-1].strip(), page_body(p, d.images), ents))
            else:
                d.content.setdefault(code, []).extend(page_body(p, d.images)); d.entries.setdefault(code, []).extend(ents)
    return m23, docs32, unmapped

# product data per document
DS_SD = ["sakuramil", "cp-4", "cp-6", "cp-7", "cp-8", "cp-9-1"]
def product_keys(doc):
    k = [x for x in R if x.startswith("Organization/")]
    if doc.subject_ds:
        k = [f"SubstanceDefinition/{s}" for s in DS_SD if f"SubstanceDefinition/{s}" in R] + k
    else:
        k = ["MedicinalProductDefinition/sakura-bloom-20mg", "ManufacturedItemDefinition/sakura-bloom-20mg-tablet"] + \
            [x for x in R if x.startswith("PackagedProductDefinition/")] + [x for x in R if x.startswith("Ingredient/")] + k
    return [x for x in dict.fromkeys(k) if x in R]

def refs_in(x, acc):
    if isinstance(x, dict):
        r = x.get("reference")
        if isinstance(r, str) and "/" in r and not r.startswith("#"): acc.add(r)
        for v in x.values(): refs_in(v, acc)
    elif isinstance(x, list):
        for v in x: refs_in(v, acc)

def closure(keys):
    seen, todo = OrderedDict(), list(keys)
    while todo:
        k = todo.pop(0)
        if k in seen or k not in R: continue
        seen[k] = True
        acc = set(); refs_in(R[k], acc)
        todo += sorted(acc - set(seen))
    return list(seen)

def gen_table(keys):
    d = ET.Element(f"{{{XH}}}div")
    tb = ET.SubElement(d, f"{{{XH}}}table")
    tr = ET.SubElement(tb, f"{{{XH}}}tr")
    for h in ("Resource", "Name"):
        ET.SubElement(tr, f"{{{XH}}}th").text = h
    for k in keys:
        tr = ET.SubElement(tb, f"{{{XH}}}tr")
        ET.SubElement(tr, f"{{{XH}}}td").text = k
        nm = names_of(R[k]) if k in R else []
        ET.SubElement(tr, f"{{{XH}}}td").text = nm[-1] if nm else ""
    return d

def build_doc(doc, ptype):
    """Return a document Bundle (dict) for one Doc at PQI type ptype."""
    subj_key = "SubstanceDefinition/sakuramil" if doc.subject_ds else "MedicinalProductDefinition/sakura-bloom-20mg"
    subj_disp = "Sakuramil (IROHA-corp)" if doc.subject_ds else "Sakura Bloom 20 mg film-coated tablets"
    prof = lambda kind: f"{SD}{kind}-type{ptype}-pq"
    used_imgs = OrderedDict()
    linked = []         # resource keys referenced from CTD sections

    def section(code, prefix=""):
        s = OrderedDict(); s["title"] = DISP[code]
        s["code"] = {"coding": [{"system": CTD, "code": code, "display": DISP[code]}]}
        kids = children(code)
        els = doc.content.get(code)
        ents = [e for e in dict.fromkeys(doc.entries.get(code, [])) if e in R]
        has_text = bool(els)
        div = make_div(copy.deepcopy(els) if els else [], None if not kids else SEE_PARENT) if (els or not kids) else None
        if not els and not kids:
            div = make_div([], SEE_PARENT if parent(code) in doc.content else NOT_PROVIDED)
        img_ids = []
        if div is not None:
            for img in div.iter(f"{{{XH}}}img"):
                iid = img.get("src").split("/", 1)[1]; img_ids.append(iid); used_imgs[iid] = doc.images[iid]
        entries = [{"reference": f"DocumentReference/fig-{i[4:]}"} for i in dict.fromkeys(img_ids)]
        if ptype == 4 and code in REPLACEABLE:   # entries of replaceable headings are limited to the allowed types
            ents = [e for e in ents if e.split("/")[0] in REPLACEABLE[code]]
        if ptype >= 3 and ents:
            replace = ptype == 4 and code in REPLACEABLE and not kids
            if replace:
                allowed = [e for e in ents if e.split("/")[0] in REPLACEABLE[code]]
                if allowed:
                    div = gen_table(allowed); has_text = False
                    entries += [{"reference": e} for e in allowed]; linked.extend(allowed)
                    s["text"] = {"status": "generated", "div": div_str(div)}
                    if kids: s["section"] = [section(k) for k in kids]
                    s["entry"] = entries
                    return s
            sid_base = "s" + code.lower().replace(".", "-")
            fallback_id = None
            for i, e in enumerate(ents):
                hid = None
                for nm in names_of(R[e]):
                    cand = f"{sid_base}-{e.split('/')[0].lower()}-{i+1}"
                    if wrap_first(div, nm, cand): hid = cand; break
                if not hid:
                    if not fallback_id:
                        fallback_id = f"{sid_base}-text"
                        first = next((x for x in div if x.tag != f"{{{XH}}}img"), None)
                        if first is not None: first.set("id", fallback_id)
                    hid = fallback_id
                entries.append({"extension": [{"url": "http://hl7.org/fhir/StructureDefinition/textLink", "extension": [
                    {"url": "htmlid", "valueString": hid}, {"url": "data", "valueUri": e}]}], "reference": e})
                linked.append(e)
        if div is not None:
            s["text"] = {"status": "additional", "div": div_str(div)}
        if kids: s["section"] = [section(k) for k in kids]
        if entries: s["entry"] = entries
        return s

    secs = [section(c) for c in doc.top]
    # 3.2.R regional sub-sections: the regulator's own headings (no ctd-section-pq code)
    if doc.top == ["3.2.R"]:
        r = secs[0]; r.pop("text", None)
        r["text"] = {"status": "additional", "div": div_str(make_div([], "Regional information for the United States. Sub-sections use the regulator's own headings."))}
        subs = []
        for title, els, ents in doc.regional:
            div = make_div(copy.deepcopy(els))
            for img in div.iter(f"{{{XH}}}img"):
                iid = img.get("src").split("/", 1)[1]; used_imgs[iid] = doc.images[iid]
            sub = OrderedDict([("title", title), ("code", {"text": "US regional information: " + title}), ("text", {"status": "additional", "div": div_str(div)})])
            subs.append(sub)
        r["section"] = subs
    # Type 2+: product data section
    prod = product_keys(doc) if ptype >= 2 else []
    if ptype >= 2:
        pd_keys = [k for k in prod if k not in linked and k != subj_key]
        if pd_keys:
            secs.insert(0, OrderedDict([("title", "Product data"), ("code", {"coding": [{"system": CTD, "code": "pqi-product-data", "display": "Product data"}]}),
                                        ("text", {"status": "generated", "div": div_str(gen_table(pd_keys))}), ("entry", [{"reference": k} for k in pd_keys])]))
    comp = OrderedDict()
    comp["resourceType"] = "Composition"; comp["id"] = f"{doc.did}-type{ptype}"
    comp["meta"] = {"profile": [prof("Composition")]}
    comp["identifier"] = [{"system": BASE + "/document-id", "value": f"{doc.did}-type{ptype}"}]
    comp["status"] = "final"
    comp["type"] = {"coding": [{"system": PQ_CS + "pqi-document-type", "code": doc.doc_type}]}
    comp["category"] = [{"coding": [{"system": PQ_CS + "pqi-maturity-type", "code": f"type-{ptype}"}]}]
    if ptype == 1:
        comp["subject"] = [{"display": subj_disp}]; comp["author"] = [{"display": "Sakura Pharma"}]
    else:
        comp["subject"] = [{"reference": subj_key, "display": subj_disp}]; comp["author"] = [{"reference": "Organization/sakura-pharma", "display": "Sakura Pharma"}]
    comp["date"] = DATE
    top_title = DISP[doc.top[0]] if doc.top[0] != "2.3" else "Quality Overall Summary"
    comp["title"] = f"{doc.top[0]} {top_title} - Sakura Bloom 20 mg film-coated tablets (ICH SakuraBloom mock-up, PQI Type {ptype})" + (" - United States" if doc.top == ["3.2.R"] else "")
    comp["section"] = secs
    # resources
    keys = []
    if ptype >= 2:
        keys = closure([subj_key, "Organization/sakura-pharma"] + prod + linked)
        if ptype == 2:  # Type 2 Bundles are closed to product data resources
            keys = [k for k in keys if k.split("/")[0] in ("MedicinalProductDefinition", "ManufacturedItemDefinition", "PackagedProductDefinition",
                                                          "Ingredient", "SubstanceDefinition", "Organization", "AdministrableProductDefinition", "RegulatedAuthorization")]
    entries = [{"fullUrl": full(f"Composition/{comp['id']}"), "resource": comp}]
    for iid, meta in used_imgs.items():
        fid = "fig-" + iid[4:]
        entries.append({"fullUrl": full(f"DocumentReference/{fid}"), "resource": OrderedDict([
            ("resourceType", "DocumentReference"), ("id", fid), ("meta", {"profile": [SD + "DocumentReference-drug-pq"]}), ("status", "current"),
            ("type", {"text": "Figure"}), ("description", meta.get("caption") or meta["name"]),
            ("content", [{"attachment": {"contentType": "image/png", "url": f"Binary/{iid}", "title": f"Placeholder for '{meta['name']}' (image not in the extract)"}}])])})
        entries.append({"fullUrl": full(f"Binary/{iid}"), "resource": OrderedDict([("resourceType", "Binary"), ("id", iid), ("contentType", "image/png"), ("data", PNG)])})
    for k in keys:
        entries.append({"fullUrl": full(k), "resource": scrub(R[k], keys)})
    b = OrderedDict([("resourceType", "Bundle"), ("id", f"bundle-document-type{ptype}-pq-{doc.did}"), ("meta", {"profile": [prof("Bundle-document")]}),
                     ("identifier", {"system": "urn:ietf:rfc:3986", "value": uid(f"{doc.did}-type{ptype}")}), ("type", "document"), ("timestamp", TS), ("entry", entries)])
    b["meta"]["profile"] = [f"{SD}Bundle-document-type{ptype}-pq"]
    return b

def scrub(r, keys):
    """Copy a resource; drop references to resources that are not in this document (keeps documents self-contained)."""
    r = copy.deepcopy(r)
    keyset = set(keys)
    def walk(x):
        if isinstance(x, dict):
            for k in list(x):
                v = x[k]
                if isinstance(v, dict) and isinstance(v.get("reference"), str) and "/" in v["reference"] and v["reference"] not in keyset:
                    v.pop("reference");
                    if not v: x.pop(k)
                else: walk(v)
        elif isinstance(x, list):
            for i in range(len(x) - 1, -1, -1):
                v = x[i]
                if isinstance(v, dict) and isinstance(v.get("reference"), str) and "/" in v["reference"] and v["reference"] not in keyset:
                    v.pop("reference")
                    if not v: x.pop(i)
                else: walk(v)
    walk(r)
    return r

def collection(cid, docs):
    return OrderedDict([("resourceType", "Bundle"), ("id", cid), ("meta", {"profile": [SD + "Bundle-document-collection-pq"]}),
                        ("identifier", {"system": "urn:ietf:rfc:3986", "value": uid(cid)}), ("type", "collection"), ("timestamp", TS),
                        ("entry", [{"fullUrl": uid(d["id"]), "resource": d} for d in docs])])

def build(S, outdir, types=(1, 2, 3, 4)):
    m23, docs32, unmapped = collect(S)
    os.makedirs(outdir, exist_ok=True)
    out = {}
    for t in types:
        out[(t, "m23")] = build_doc(m23, t)
        out[(t, "m32")] = {r: build_doc(d, t) for r, d in docs32.items()}
        d = os.path.join(outdir, f"type{t}"); os.makedirs(d, exist_ok=True)
        json.dump(out[(t, "m23")], open(f"{d}/bundle-document-type{t}-pq-sakura-bloom-m23.json", "w"), ensure_ascii=False, indent=1)
        json.dump(collection(f"bundle-document-collection-pq-sakura-bloom-m32-type{t}", list(out[(t, "m32")].values())),
                  open(f"{d}/bundle-document-collection-pq-sakura-bloom-m32-type{t}.json", "w"), ensure_ascii=False, indent=1)
    return out, unmapped
