**Full Implementation Guide**

The entire implementation guide (including the HTML files, definitions, validation information, etc.) may be downloaded [here](full-ig.zip).

In addition there are format specific definitions files.

* [XML](definitions.xml.zip)
* [JSON](definitions.json.zip)
* [TTL](definitions.ttl.zip)

**Examples:** all the examples that are used in this Implementation Guide available for download:

* [XML](examples.xml.zip)
* [JSON](examples.json.zip)
* [TTL](examples.ttl.zip)

**PQI document starter files:** empty PQI Type 1 documents with every ICH M4Q(R1) heading coded, ready to fill:

* [Module 2.3 Quality Overall Summary skeleton](Bundle-bundle-document-type1-pq-m23-r1-skeleton.html)
* [Module 3.2 skeleton](Bundle-bundle-document-collection-pq-m32-r1-skeleton.html): one document per level-3 heading, in a document collection

**Sakura Bloom examples:** 3.2.P.3, 3.2.P.7 and 3.2.R (US) from the ICH Sakura Bloom mock-up, at each type:

* [Type 1](Bundle-bundle-document-collection-pq-sakura-bloom-type1.html) · [Type 2](Bundle-bundle-document-collection-pq-sakura-bloom-type2.html) · [Type 3](Bundle-bundle-document-collection-pq-sakura-bloom-type3.html) · [Type 4](Bundle-bundle-document-collection-pq-sakura-bloom-type4.html)

**Full Sakura Bloom set:** the Module 2.3 document and all nineteen Module 3.2 documents at Types 1–4 are in the [GitHub parking lot](https://github.com/HL7/uv-dx-pq/tree/master/parking-lot/sakura-bloom). All of this example data is synthetic. It comes from the ICH M4Q(R2) Sakura Bloom mock-up, the FDA example Quality Overall Summaries and the HL7 FHIR PQI team's example data. Content none of these provide is marked as synthetic where it appears, the US marketing authorization is made up, and every document is labelled as test data (HTEST).

Templates based on the Health Canada templates will be added to the parking lot later.
