# Sakura Bloom PQI Type 1–4 example generator (private)

Private: kept outside the uv-dx-pq repo on purpose and not to be published or shared. It writes into a uv-dx-pq checkout.

Builds PQI Type 1–4 documents from the ICH M4Q(R2) "Sakura Bloom" mock-up (`source/sakura-bloom-r2-extract.json`).

```
python3 generator/run_pqi_types.py ../uv-dx-pq
```

Outputs:

* `parking-lot/sakura-bloom/type1..type4`: the full set. For each type, a Module 2.3 Quality Overall Summary document and a collection of nineteen Module 3.2 documents (one per level-3 M4Q(R1) heading, plus 3.2.R for the United States).
* `input/examples`: the in-IG subset. One collection per type with the 3.2.P.3, 3.2.P.7 and 3.2.R (US) documents.

How the content is placed:

* The mock-up uses M4Q(R2) headings. `pqi_types.py` places each page under its M4Q(R1) heading, following the ICH document "Mapping R1 versus R2" (12 January 2026).
* `part1_core.py` to `part4_docs_bundles.py` build the PQI resources (substances, product, specifications, batches, stability, procedures) from the mock-up.
* `pqi_fill.py` fills the M4Q(R1) headings the mock-up does not cover. S.1.1 to S.1.3 are written from the mock-up's substance data. The others are synthetic, written in the structure of the FDA sample sections in `input/examples-pdf` but with Sakura Bloom's own composition, sites and packs. Each filled section says where its content comes from.
* `pqi_fill.py` also adds a made-up US marketing authorization (RegulatedAuthorization) for Sakura Bloom 20 mg.
* Figures (`pqi_figures.py`): the extract has no image files, so each figure is rebuilt. Chromatograms, NMR and mass spectra, linearity plots, structures and flow diagrams are redrawn from the data and names in the mock-up. IR, UV, XRPD and the stability trend chart come from the synthetic PQI example PDFs (`pdf-images`, extracted from uv-dx-pq `input/examples-pdf` at their original resolution). Dissolution curves, development charts, certificates and the product configuration are synthetic illustrations. Images the generator cannot rebuild (mainly table images) are labelled placeholders. Each figure's DocumentReference says which of these it is.

Requirements: Python 3 with matplotlib, numpy, pillow and rdkit, and Graphviz (`dot`).

## IG tools (`ig-tools`)

Scripts that generate parts of the uv-dx-pq IG. They live here, not in the IG repo, so they stay private.

* `generate_pqi_document_types.py <ig>/input/fsh/documents`: writes `terminology.fsh` (the ctd-section-pq CodeSystem and value sets, document and maturity type codes) and `examples-skeleton.fsh` (the M4Q(R1) Type 1 skeleton examples).
* `pages.py <ig>/input/pagecontent` (with `ui.py`): writes the Build pages (`build.md`, `build_type1.md` to `build_type4.md`, `build_validate.md`) in the ePI-style layout.
