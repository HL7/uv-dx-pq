"""Content for M4Q(R1) headings that the ICH Sakura Bloom mock-up does not cover, plus a made-up marketing authorization.

* S.1.1-S.1.3 are written from the Sakuramil substance data that is in the mock-up.
* The rest is synthetic: written for these examples, using the structure of the FDA sample Module 3 sections
  (input/examples-pdf in uv-dx-pq) but with Sakura Bloom's own composition, sites and packs.
Every filled section ends with a note saying where its content comes from.
"""
from lib import R, SD, BASE

NOTE_SYN = "_Synthetic content written for the PQI examples, based on the FDA example Quality Overall Summaries and the FHIR PQI team's synthetic example data. It is not part of the ICH Sakura Bloom mock-up._"
NOTE_DATA = "_Written from the Sakuramil substance data in the ICH Sakura Bloom mock-up._"


def _names():
    sd = R["SubstanceDefinition/sakuramil"]
    rows = "\n".join(f"| {n['type']['text']} | {n['name']} |" for n in sd.get("name", []))
    cas = sd["identifier"][0]["value"]
    return f"""| Name type | Name |
|---|---|
{rows}
| CAS registry number | {cas} |

{NOTE_DATA}"""


def _structure():
    st = R["SubstanceDefinition/sakuramil"].get("structure", {})
    mw = R["SubstanceDefinition/sakuramil"].get("molecularWeight", [{}])[0].get("amount", {})
    return f"""| Item | Value |
|---|---|
| Molecular formula | {st.get('molecularFormula', '')} |
| Relative molecular mass | {mw.get('value', '')} {mw.get('unit', '')} (free base) |
| Stereochemistry | {st.get('stereochemistry', {}).get('text', '')}; two stereocentres |
| Chemical name | {st.get('representation', [{}])[0].get('representation', '')} |

{NOTE_DATA}"""


def _properties():
    rows = []
    for p in R["SubstanceDefinition/sakuramil"].get("property", []):
        v = p.get("valueCodeableConcept", {}).get("text")
        if v is None and "valueQuantity" in p:
            q = p["valueQuantity"]; v = f"{q.get('comparator', '')}{q['value']} {q.get('unit', '')}".strip()
        if v is None: v = p.get("valueString", "")
        rows.append(f"| {p['type'].get('text', '')} | {v} |")
    return "| Property | Result |\n|---|---|\n" + "\n".join(rows) + f"\n\n{NOTE_DATA}"


TEXT = {
"3.2.S.2.5": f"""The commercial manufacturing process for Sakuramil (CP-9) was validated at IROHA-corp. by manufacturing three consecutive batches at commercial scale (target 150 kg ± 10% of the final intermediate input).

Process validation covered all chemical steps from the starting materials CP-4 and CP-8 through the intermediates CP-6 and CP-7 to the final crystallisation and milling. The acceptance criteria were the critical in-process controls, the intermediate release limits and the drug substance specification (3.2.S.4.1).

| Batch | Date of manufacture | Batch size (kg) | Overall yield (%) | Result |
|---|---|---|---|---|
| PV-CP9-001 | 2024-03-04 | 148.2 | 71.4 | Complies |
| PV-CP9-002 | 2024-03-25 | 151.0 | 72.0 | Complies |
| PV-CP9-003 | 2024-04-15 | 149.6 | 71.1 | Complies |

All critical in-process controls were within their acceptance criteria and all batches met the drug substance specification. The process is considered validated. Ongoing performance is followed by continued process verification.

{NOTE_SYN}""",

"3.2.P.2.1.1": f"""Sakuramil is practically insoluble in water and in acidic media (3.2.S.1.3), and is used as a single crystalline form. A fine particle size is therefore controlled in the drug substance specification to support dissolution.

Compatibility of Sakuramil with the selected excipients was shown in binary mixtures stored at 40 °C/75% RH for 3 months. No new degradation products above the reporting threshold were observed.

{NOTE_SYN}""",

"3.2.P.2.1.2": f"""The excipients and their functions are listed in 3.2.P.1. All excipients except the coating premix are of compendial grade (Ph. Eur./USP-NF).

| Excipient | Function | Reason for selection |
|---|---|---|
| Lactose monohydrate | Diluent | Good compressibility; standard in wet granulation |
| Microcrystalline cellulose | Diluent | Improves tablet hardness and friability |
| Croscarmellose sodium | Disintegrant | Rapid disintegration needed for an insoluble drug substance |
| Hydroxypropyl cellulose | Binder | Granule strength at a low level |
| Magnesium stearate | Lubricant | Standard lubricant; level kept low to protect dissolution |
| Basic coating premix red | Film coating | Colour, identification and ease of swallowing |

The levels were chosen in formulation development (3.2.P.2.2.1).

{NOTE_SYN}""",

"3.2.P.2.2.1": f"""Sakura Bloom 20 mg is an immediate-release film-coated tablet made by wet granulation. Wet granulation was chosen over direct compression because the low drug load and the poor flow of the micronised drug substance gave poor content uniformity in direct-compression trials.

| Formulation | Composition | Change | Development phase |
|---|---|---|---|
| F1 | Uncoated core, 194 mg | First formulation | Phase 1 |
| F2 | Core as F1, croscarmellose sodium raised from 6 to 10 mg | Faster disintegration | Phase 2 |
| F3 (commercial) | F2 core plus 6 mg red film coat | Film coat added for identification and light protection | Phase 3 and commercial |

Formulation F3 was used for the registration stability batches and is the commercial formulation.

{NOTE_SYN}""",

"3.2.P.2.2.2": f"""There are no overages in the formulation of Sakura Bloom 20 mg film-coated tablets.

{NOTE_SYN}""",

"3.2.P.2.2.3": f"""The properties that matter for performance are dissolution, disintegration and the particle size of the drug substance. Dissolution is controlled in the drug product specification (3.2.P.5.1). Drug substance particle size is controlled in the drug substance specification (3.2.S.4.1). Tablet hardness and friability are controlled as in-process tests (3.2.P.3.4).

{NOTE_SYN}""",

"3.2.P.2.4": f"""The container closure systems are described in 3.2.P.7: an HDPE bottle with a child-resistant polypropylene cap and a desiccant, a PA/Al/PVC–aluminium blister, and an aluminium bag for bulk storage.

Suitability was shown as follows:

- **Protection:** water vapour transmission of both commercial packs met the Ph. Eur. 3.2 and USP <671> criteria. The registration stability studies (3.2.P.8.3) showed no meaningful change in water content or degradation products.
- **Safety:** all product-contact materials comply with Ph. Eur. 3.1 or USP <661> and with food-contact regulations.
- **Compatibility:** no interaction between the tablets and the packaging was seen on stability.
- **Performance:** the bottle closure passed the child-resistance test (ISO 8317).

{NOTE_SYN}""",

"3.2.P.2.5": f"""Sakura Bloom 20 mg is a non-sterile oral solid dosage form with low water activity. All excipients meet the compendial microbiological requirements (USP <1111>, Ph. Eur. 5.1.4).

Three commercial-scale batches met the USP <1111> criteria for non-aqueous oral preparations (TAMC NMT 10³ CFU/g, TYMC NMT 10² CFU/g, absence of _E. coli_). Based on a microbial risk assessment, microbial enumeration is tested at release on the first three commercial batches and then annually and on stability.

{NOTE_SYN}""",

"3.2.P.2.6": f"""Not applicable. Sakura Bloom 20 mg film-coated tablets are swallowed whole and are not reconstituted, diluted or given with a dosing device.

{NOTE_SYN}""",

"3.2.P.3.2": f"""The batch quantities below are for the commercial batch size of 120.0 kg of film-coated tablets (600,000 tablets).

| Component | mg per tablet | kg per batch |
|---|---|---|
| **Tablet core** | | |
| Sakuramil | 20.0 | 12.00 |
| Lactose monohydrate | 136.0 | 81.60 |
| Microcrystalline cellulose | 20.0 | 12.00 |
| Croscarmellose sodium | 10.0 | 6.00 |
| Hydroxypropyl cellulose | 6.0 | 3.60 |
| Magnesium stearate | 2.0 | 1.20 |
| Purified water¹ | q.s. | q.s. |
| **Core weight** | **194.0** | **116.40** |
| **Film coat** | | |
| Basic coating premix red | 6.0 | 3.60 |
| Purified water¹ | q.s. | q.s. |
| **Total** | **200.0** | **120.00** |

¹ Removed during processing.

{NOTE_SYN}""",

"3.2.P.3.4": f"""| Step | Control | Acceptance criterion |
|---|---|---|
| Granulation | End-point by impeller power consumption | Within the validated range |
| Drying | Loss on drying of the granules | NMT 2.0% |
| Blending | Blend uniformity (stratified sampling) | 90.0–110.0% of label claim, RSD NMT 5.0% |
| Compression | Tablet weight | 194.0 mg ± 5% |
| Compression | Hardness | 60–120 N |
| Compression | Friability | NMT 1.0% |
| Compression | Disintegration | NMT 15 min |
| Coating | Weight gain | 2.5–3.5% |

There are no isolated intermediates other than the core tablets, which can be held for up to 90 days in double polyethylene bags before coating.

{NOTE_SYN}""",

"3.2.P.3.5": f"""The commercial manufacturing process was validated at Aparna Pharmaceutical Manufacturing Pte. Ltd. with three consecutive commercial-scale batches (120 kg) under an approved protocol. The validation covered granulation, drying, blending, compression and coating.

| Batch | Date of manufacture | Batch size (kg) | Yield (%) | Result |
|---|---|---|---|---|
| SB20-PV1 | 2024-06-03 | 120.0 | 98.1 | Complies |
| SB20-PV2 | 2024-06-10 | 120.0 | 97.6 | Complies |
| SB20-PV3 | 2024-06-17 | 120.0 | 98.4 | Complies |

All in-process controls (3.2.P.3.4) and release results (3.2.P.5.4) were within their acceptance criteria. Blend and content uniformity were consistent across the batches. The process is considered validated.

{NOTE_SYN}""",

"3.2.P.4.5": f"""| Excipient | Biological source | Suitability for use |
|---|---|---|
| Lactose monohydrate | Bovine milk | Sourced from milk fit for human consumption, collected under the same conditions as milk for human use; complies with the EMA note for guidance on minimising the risk of TSE (EMA/410/01). |

Magnesium stearate is of vegetable origin. No other excipient is of human or animal origin.

{NOTE_SYN}""",

"3.2.P.5.5": f"""Organic impurities of the drug substance are described in 3.2.S.3.2. The degradation products of the drug product are controlled in the drug product specification (3.2.P.5.1).

**Elemental impurities.** No elemental impurities are added during drug product manufacture. A risk assessment following ICH Q3D covered the drug substance, the excipients, the manufacturing equipment and the packaging. Three batches tested for Cd, Pb, As, Hg, Co, V and Ni were below 30% of the permitted daily exposure, so no routine testing is proposed.

**Nitrosamines.** A risk assessment following ICH M7 and Q9 found no nitrosating agents together with vulnerable amines in the drug substance, excipients, process or packaging. No risk of nitrosamine impurities was identified.

{NOTE_SYN}""",

"3.2.P.6": f"""The reference standards used to test the drug product are the Sakuramil primary and working reference standards, and the impurity reference standards, described in 3.2.S.5. No reference standards are specific to the drug product.

{NOTE_SYN}""",

"3.2.A.2": f"""Sakura Bloom 20 mg film-coated tablets contain no materials of human origin. The only material of animal origin is lactose monohydrate, which is derived from bovine milk fit for human consumption (3.2.P.4.5). No viral safety evaluation is needed.

{NOTE_SYN}""",

"3.2.A.3": f"""Sakura Bloom 20 mg film-coated tablets contain no novel excipients (see 3.2.P.4.6).

{NOTE_SYN}""",
}

FILL_ENTRIES = {"3.2.S.1.1": ["SubstanceDefinition/sakuramil"], "3.2.S.1.2": ["SubstanceDefinition/sakuramil"],
                "3.2.S.1.3": ["SubstanceDefinition/sakuramil"], "3.2.P.3.5": ["Organization/aparna-pharm"],
                "3.2.S.2.5": ["Organization/iroha-corp"], "3.2.P.4.5": ["Ingredient/ing-lactose-monohydrate"]}


def fill_text():
    t = dict(TEXT)
    t["3.2.S.1.1"], t["3.2.S.1.2"], t["3.2.S.1.3"] = _names(), _structure(), _properties()
    return t


def add_authorization():
    """A made-up US marketing authorization for Sakura Bloom 20 mg (no such authorization exists)."""
    R["RegulatedAuthorization/sakura-bloom-20mg-us"] = {
        "resourceType": "RegulatedAuthorization", "id": "sakura-bloom-20mg-us",
        "meta": {"profile": [SD + "RegulatedAuthorization-drug-pq"]},
        "identifier": [{"system": BASE + "/application-number", "value": "NDA-SB-000020"}],
        "subject": [{"reference": "MedicinalProductDefinition/sakura-bloom-20mg"}],
        "type": {"coding": [{"system": "http://hl7.org/fhir/regulated-authorization-type", "code": "MarketingAuth", "display": "Marketing Authorization"}]},
        "description": "Marketing authorization for Sakura Bloom 20 mg film-coated tablets in the United States. Fictitious: made up for the PQI examples.",
        "region": [{"coding": [{"system": "urn:iso:std:iso:3166", "code": "US", "display": "United States of America"}]}],
        "status": {"coding": [{"system": "http://hl7.org/fhir/publication-status", "code": "active", "display": "Active"}]},
        "statusDate": "2025-11-14",
        "validityPeriod": {"start": "2025-11-14"},
        "holder": {"reference": "Organization/sakura-pharma"},
    }
    return "RegulatedAuthorization/sakura-bloom-20mg-us"

NOTE_SUM = "_Summary written for the PQI examples from content elsewhere in the ICH Sakura Bloom mock-up._"

M23_TEXT = {
"2.3.S.6": f"""Sakuramil is packed in low-density polyethylene (LDPE) bags closed with a tie-wrap. The secondary packaging is not a functional component. The re-test period is 36 months when stored at 15–30 °C (2.3.S.7; 3.2.S.6).

{NOTE_SUM}""",
"2.3.P.6": f"""The drug product is tested against the Sakuramil and impurity reference standards described in 2.3.S.5. No reference standards are specific to the drug product (3.2.P.6).

{NOTE_SYN}""",
"2.3.P.7": f"""The tablets are packed in an HDPE bottle with a child-resistant polypropylene cap and desiccant, or in PA/Al/PVC–aluminium blisters. Bulk tablets are stored in aluminium bags before packaging. The suitability of the packs is discussed in 3.2.P.2.4 and they are described in 3.2.P.7.

{NOTE_SUM}""",
"2.3.A.1": f"""Sakuramil and its intermediates CP-6 and CP-7 are manufactured and tested by IROHA-corp. (China). Sakura Bloom 20 mg is manufactured, tested and packaged by Aparna Pharmaceutical Manufacturing Pte. Ltd. (Bangladesh), with microbiological testing at Kunchen SA (Germany), other testing at Dakina Analytica SA (Switzerland), and packaging at Pack Alpha Group and Cocopharma AG (Switzerland). The facilities are listed in 3.2.S.2.1, 3.2.P.3.1 and 3.2.A.1.

{NOTE_SUM}""",
"2.3.A.2": f"""The product contains no materials of human origin. Lactose monohydrate is the only material of animal origin and is sourced from bovine milk fit for human consumption (3.2.A.2).

{NOTE_SYN}""",
"2.3.A.3": f"""The product contains no novel excipients (3.2.A.3).

{NOTE_SYN}""",
}
