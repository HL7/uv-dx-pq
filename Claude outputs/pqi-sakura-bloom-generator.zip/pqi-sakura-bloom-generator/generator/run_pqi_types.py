"""Build the PQI Type 1-4 Sakura Bloom examples into the IG repo.

Usage:  python3 generator/run_pqi_types.py [path to uv-dx-pq]     (default: ../uv-dx-pq next to this folder)
Writes the full set to <ig>/parking-lot/sakura-bloom/type1..type4 and the in-IG subset to <ig>/input/examples.
Needs: matplotlib, numpy, pillow, rdkit, graphviz (dot).
"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from lib import *
import part1_core, part2_specs, part3_process_data, pqi_types, ig_subset
IG = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "..", "uv-dx-pq"))
S = Source(os.path.join(HERE, "..", "source", "sakura-bloom-r2-extract.json"))
part1_core.build(S); part2_specs.build(S); part3_process_data.build(S); finalize()
FULL = os.path.join(IG, "parking-lot", "sakura-bloom")
out, unmapped = pqi_types.build(S, FULL)
print("full set:", FULL)
for u in unmapped: print("  not placed (no M4Q(R1) heading):", u)
ig_subset.write(FULL, os.path.join(IG, "input", "examples"))
