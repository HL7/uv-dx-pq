"""Figures for the Sakura Bloom PQI examples.

The mock-up extract has no image files. Each figure is rebuilt from what the mock-up says around it:
  * data-driven: chromatograms (retention times), NMR spectra (shift tables), mass spectra (m/z), linearity plots
    (calibration tables), structures (from the IUPAC names, drawn with RDKit), flow diagrams (process steps);
  * taken from the synthetic PQI example data (uv-dx-pq input/examples-pdf): IR, UV and XRPD figures and the
    stability trend chart, kept at their original resolution;
  * taken from the FDA example Quality Overall Summary for an immediate-release tablet (dissolution profiles,
    the quality-attribute diagram and the contour plots), cropped from the PDF rendered at 200 dpi;
  * synthetic illustrations where the mock-up gives no data (dissolution curves, certificates, product configuration).
render(meta) returns (png_bytes, source_note).
"""
import io, os, re, hashlib, functools
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

PDF_IMG = os.environ.get("PQI_PDF_IMAGES", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pdf-images"))
DATA = "Redrawn for the PQI examples from data given in the ICH Sakura Bloom mock-up."
STRUCT = "Structure drawn for the PQI examples from the IUPAC name given in the ICH Sakura Bloom mock-up."
PDF = "Figure taken from the synthetic PQI example data (input/examples-pdf); it does not show Sakura Bloom data."
FDA = "Figure taken from the FDA example Quality Overall Summary for an immediate-release tablet; it does not show Sakura Bloom data."
SYN = "Synthetic illustration made for the PQI examples; the mock-up gives no data for this figure."
DPI = 150

SMILES = {  # stereo chosen to match the CIP labels in the IUPAC names (checked with RDKit)
    "sakuramil": ("CO[C@@]1(C)C[C@H](N(Cc2cc(C(F)(F)F)cc(C(F)(F)F)c2)C(C)=O)c2cc(C(F)(F)F)ccc2N1C(=O)OC(C)C", "Sakuramil (CP-9)"),
    "cp-9-1": ("CCO[C@@]1(C)C[C@H](N(Cc2cc(C(F)(F)F)cc(C(F)(F)F)c2)C(C)=O)c2cc(C(F)(F)F)ccc2N1C(=O)OC(C)C", "CP-9-1"),
    "cp-6": ("CCC[C@@H]1C[C@H](NC(=O)OC)c2cc(C(F)(F)F)ccc2N1", "CP-6"),
    "cp-7": ("CCC[C@@H]1C[C@H](NC(=O)OC)c2cc(C(F)(F)F)ccc2N1C(=O)OCC", "CP-7"),
    "cp-4": ("CCC[C@H](CC(N)=O)Nc1ccc(C(F)(F)F)cc1", "CP-4"),
    "cp-8": ("FC(F)(F)c1cc(CBr)cc(C(F)(F)F)c1", "CP-8"),
    "cp-8-oh": ("OCc1cc(C(F)(F)F)cc(C(F)(F)F)c1", "CP-8-OH"),
    "cp-8-cho": ("O=Cc1cc(C(F)(F)F)cc(C(F)(F)F)c1", "3,5-bis(trifluoromethyl)benzaldehyde"),
}


def _png(fig):
    b = io.BytesIO(); fig.savefig(b, format="png", dpi=DPI, bbox_inches="tight", facecolor="white"); plt.close(fig)
    return b.getvalue()


def _fig(w=8, h=3.6):
    fig, ax = plt.subplots(figsize=(w, h))
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    return fig, ax


def _which(text):
    t = text.lower()
    for k in ("cp-9-1", "cp-8", "cp-7", "cp-6", "cp-4"):
        if k in t: return k
    if "sakuramil" in t or "cp-9" in t: return "sakuramil"
    return None


# ----------------------------------------------------------------------------- structures (RDKit)
def _mol_png(keys, numbers=False, labels=None, size=(520, 400), per_row=None):
    from rdkit import Chem
    from rdkit.Chem import Draw
    from rdkit.Chem.Draw import rdMolDraw2D
    mols = [Chem.MolFromSmiles(SMILES[k][0]) for k in keys]
    for m in mols:
        if numbers:
            for a in m.GetAtoms():
                if a.GetSymbol() == "C": a.SetProp("atomNote", str(a.GetIdx() + 1))
    opts = rdMolDraw2D.MolDrawOptions(); opts.addStereoAnnotation = True; opts.legendFontSize = 18
    img = Draw.MolsToGridImage(mols, molsPerRow=per_row or len(mols), subImgSize=size,
                               legends=labels or [SMILES[k][1] for k in keys], drawOptions=opts, returnPNG=False)
    b = io.BytesIO(); img.save(b, format="PNG"); return b.getvalue()


def stereoisomers():
    from rdkit import Chem
    from rdkit.Chem import Draw
    from rdkit.Chem.EnumerateStereoisomers import EnumerateStereoisomers
    base = Chem.MolFromSmiles(re.sub(r"@+", "", SMILES["sakuramil"][0]))
    mols, legends = [], []
    for iso in EnumerateStereoisomers(base):
        Chem.AssignCIPLabels(iso)
        c2 = iso.GetAtomWithIdx(2).GetProp("_CIPCode"); c4 = iso.GetAtomWithIdx(5).GetProp("_CIPCode")
        tag = {"SS": "Sakuramil", "RR": "enantiomer", "SR": "diastereomer", "RS": "diastereomer"}[c2 + c4]
        mols.append((c2 + c4 != "SS", iso)); legends.append((c2 + c4 != "SS", f"(2{c2},4{c4}) {tag}"))
    order = sorted(range(4), key=lambda i: mols[i][0])
    img = Draw.MolsToGridImage([mols[i][1] for i in order], molsPerRow=2, subImgSize=(520, 380),
                               legends=[legends[i][1] for i in order], returnPNG=False)
    b = io.BytesIO(); img.save(b, format="PNG"); return b.getvalue()


# ----------------------------------------------------------------------------- spectra and chromatograms
def _rt_table(ctx):
    rows = re.findall(r"\|\s*((?:CP|Sakuramil)[A-Za-z0-9\- ]*?|CP-4 Enantiomer)\s*\|\s*(\d{1,2}(?:\.\d+)?)\s*\|", ctx[-4000:])
    seen = {}
    for n, t in rows:
        seen[n.strip()] = float(t)
    return seen


def chromatogram(caption, ctx):
    rts = _rt_table(ctx) or {"CP-9": 7.2}
    names = list(rts)
    main = names[0]
    c = caption.lower()
    t = np.linspace(0, max(rts.values()) * 1.6 + 2, 3000)
    def trace(peaks):
        y = 0.4 * np.exp(-((t - 1.2) / 0.08) ** 2)  # solvent front
        for rt, h in peaks: y = y + h * np.exp(-((t - rt) / (0.06 + 0.008 * rt)) ** 2)
        return y + np.random.default_rng(int(hashlib.md5(caption.encode()).hexdigest()[:6], 16)).normal(0, 0.05, t.size)
    if "blank" in c and "overlay" not in c: sets = [("Blank", [])]
    elif "overlay" in c:
        sets = [("Blank", []), ("Reference", [(rts[main], 100)]), ("Test", [(rts[main], 100)] + [(rts[n], 2.5) for n in names[1:]])]
    elif "lod" in c: sets = [("LOD solution", [(rts[n], 1.2) for n in names])]
    elif "loq" in c: sets = [("LOQ solution", [(rts[n], 3.5) for n in names])]
    elif "identification" in c or "comparison" in c: sets = [("Solution", [(rts[n], 40 if n == main else 25) for n in names])]
    elif "test" in c: sets = [("Test solution", [(rts[main], 100)] + [(rts[n], 1.5) for n in names[1:]])]
    else: sets = [("Reference solution", [(rts[main], 100)])]
    fig, ax = _fig()
    off = 0
    for i, (lab, pk) in enumerate(sets):
        y = trace(pk) + off; ax.plot(t, y, lw=0.9, label=lab if len(sets) > 1 else None)
        for rt, h in pk:
            n = [k for k, v in rts.items() if v == rt][0]
            ax.annotate(f"{n}\n{rt:.2f}", (rt, h + off), textcoords="offset points", xytext=(0, 4), ha="center", fontsize=7)
        off += 30 if len(sets) > 1 else 0
    ax.set_xlabel("Retention time (min)"); ax.set_ylabel("Response (mAU)")
    if all(not pk for _, pk in sets): ax.set_ylim(-2, 100)
    if len(sets) > 1: ax.legend(frameon=False, fontsize=8)
    ax.set_title(caption[:90], fontsize=9)
    return _png(fig)


def _shift_rows(ctx):
    rows = []
    for m in re.finditer(r"\|\s*(\d{1,3}\.\d+)(?:\s*[–-]\s*(\d{1,3}\.\d+))?\s*\|\s*(\d+)\s*([HC])\s*\|", ctx[-3500:]):
        a, b, n, kind = m.groups(); v = (float(a) + float(b)) / 2 if b else float(a)
        rows.append((v, int(n), kind))
    return rows


def nmr(caption, ctx):
    kind = "C" if re.search(r"13C|¹³C", caption) else "H"
    rows = [r for r in _shift_rows(ctx) if r[2] == kind]
    if not rows: rows = [(7.9, 2, "H"), (7.4, 1, "H"), (4.6, 2, "H")] if kind == "H" else [(150, 1, "C"), (130, 2, "C"), (120, 2, "C")]
    hi = 10 if kind == "H" else 200
    x = np.linspace(-0.5, hi, 6000)
    y = np.zeros_like(x)
    for v, n, _ in rows: y += n * (0.02 if kind == "H" else 0.6) ** 2 / ((x - v) ** 2 + (0.02 if kind == "H" else 0.6) ** 2)
    fig, ax = _fig()
    ax.plot(x, y, lw=0.8, color="black"); ax.set_xlim(hi, -0.5); ax.set_yticks([])
    ax.set_xlabel("δ (ppm)"); ax.set_title(caption[:90], fontsize=9)
    return _png(fig)


def mass_spec(caption, ctx):
    m = re.findall(r"m/z value of sample of\s*(\d+\.\d+)", ctx[-1500:]) or re.findall(r"m/z[^.|]*?(\d{3}\.\d{3})", ctx[-1500:])
    mz = float(m[-1]) if m else 600.0
    fig, ax = _fig()
    peaks = [(mz, 100), (mz + 1.003, 28)]
    if "cp-8" in caption.lower(): peaks = [(mz, 100), (mz + 1.998, 97)]  # one bromine atom
    for p, h in peaks: ax.vlines(p, 0, h, lw=1.5)
    ax.annotate(f"{mz:.3f}", (mz, 100), textcoords="offset points", xytext=(0, 3), ha="center", fontsize=8)
    ax.set_xlim(mz - 60, mz + 60); ax.set_ylim(0, 115); ax.set_xlabel("m/z"); ax.set_ylabel("Relative intensity (%)")
    ax.set_title(caption[:90], fontsize=9)
    return _png(fig)


def linearity(caption, ctx):
    pts = []
    i = ctx.rfind("Linearity of")
    if i < 0:
        m = list(re.finditer(r"Table[^\n|]*?Linearity(?! Plot)", ctx)); i = m[-1].start() if m else -1
    block = ctx[i:] if i >= 0 else ctx[-2500:]
    block = re.split(r"Linear Regression", block)[0]
    for line in block.split("\n"):
        nums = [float(x) for x in re.findall(r"(?<![\w.])(\d+\.\d+)(?![\w.])", line)]
        if len(nums) == 3 and nums[0] < 5: pts.append((nums[2], nums[1]))
        elif len(nums) == 2 and nums[1] < 0.1: pts.append((nums[1], nums[0]))
    pts = [p for p in pts if p[0] > 0]
    if len(pts) < 4 or len(set(p[0] for p in pts)) < 3: return None
    x, y = np.array(pts).T
    k, b = np.polyfit(x, y, 1); r2 = np.corrcoef(x, y)[0, 1] ** 2
    fig, ax = _fig(6, 4)
    ax.plot(x, y, "o", ms=4); xx = np.linspace(0, x.max() * 1.05, 50); ax.plot(xx, k * xx + b, lw=1)
    ax.set_xlabel("Concentration (mg/mL)"); ax.set_ylabel("Peak area")
    ax.text(0.05, 0.9, f"y = {k:.3f}x + {b:.4f}\nR² = {r2:.5f}", transform=ax.transAxes, fontsize=8)
    ax.set_title(caption[:90], fontsize=9)
    return _png(fig)


def dissolution(caption, ctx):
    t = np.array([0, 5, 10, 15, 20, 30, 45])
    fig, ax = _fig(6.5, 4)
    if "profile of the drug product" in caption.lower():
        series = [("0.01 M HCl (pH 1.2)", 6), ("McIlvaine buffer (pH 4.0)", 11), ("Phosphate buffer (pH 6.8)", 8)]
    elif "discrimin" in ctx[-600:].lower():
        series = [("Commercial process", 7), ("Increased compression force", 13), ("Reduced disintegrant", 17)]
    elif "target q" in ctx[-600:].lower():
        series = [("Clinical batches (mean)", 8)]; ax.axhline(80, ls="--", lw=0.8, color="grey"); ax.text(46, 80, "Q = 80%", fontsize=7, va="center")
    else:
        series = [("Apparatus II, 50 rpm", 7), ("Apparatus I, 100 rpm", 10)]
    for lab, tau in series:
        ax.plot(t, 100 * (1 - np.exp(-t / tau)) * 0.99, "o-", ms=3, lw=1, label=lab)
    ax.set_xlabel("Time (min)"); ax.set_ylabel("Dissolved (% of label claim)"); ax.set_ylim(0, 105); ax.legend(frameon=False, fontsize=8)
    ax.set_title(caption[:90], fontsize=9)
    return _png(fig)


# ----------------------------------------------------------------------------- diagrams (graphviz)
def _dot(src):
    import subprocess
    return subprocess.run(["dot", "-Tpng", "-Gdpi=150"], input=src.encode(), capture_output=True, check=True).stdout


def ds_flow(step=None):
    steps = [("Step 1", "CP-4 + methyl chloroformate,\nLiOtBu, THF", "CP-5 (in situ)"),
             ("Step 2", "NaBH4, MgCl2, MeOH;\nHCl; EtOH / water", "CP-6"),
             ("Step 3", "THF, Na2CO3, ethyl chloroformate;\nNaOH, n-hexane; EtOH / water (CPP 3.1)", "CP-7"),
             ("Step 4", "CP-8, DCM, TBAB, aq. NaOH;\ncrystallisation (CPP 4.1)", "Sakuramil (CP-9)")]
    sel = steps if step is None else [steps[step]]
    lines = ['digraph G { rankdir=TB; node [shape=box, style="rounded,filled", fillcolor="#eef2ff", fontname="Helvetica", fontsize=11]; edge [fontname="Helvetica", fontsize=9];']
    prev = "CP-4 (starting material)" if (step in (None, 0)) else steps[step - 1][2]
    lines.append(f'"{prev}" [fillcolor="#fef3c7"];')
    for name, reag, prod in sel:
        lines.append(f'"{prev}" -> "{prod}" [label="  {name}: {reag}"];'); prev = prod
    lines.append(f'"{prev}" [fillcolor="#dcfce7"]; }}')
    return _dot("\n".join(lines))


def cp8_scheme():
    return _mol_png(["cp-8-cho", "cp-8-oh", "cp-8"], labels=["3,5-bis(trifluoromethyl)benzaldehyde", "CP-8-OH  (NaBH4, EtOH)", "CP-8  (bromination)"], size=(380, 300))


def generic_diagram(caption):
    c = caption.lower()
    if "fishbone" in c:
        src = 'digraph G { rankdir=LR; node [shape=box, fontname="Helvetica", fontsize=10];' + \
              "".join(f'"{x}" -> "Drug product CQAs";' for x in ["Drug substance\n(particle size, purity)", "Excipients", "Granulation\n(water amount, end-point)", "Compression\n(force, speed)", "Coating\n(weight gain)", "Packaging\n(moisture protection)"]) + "}"
    elif "fate and purge" in c or "cascade" in c or "process-related" in c:
        src = 'digraph G { rankdir=LR; node [shape=box, fontname="Helvetica", fontsize=10];' \
              '"CP-4 impurities" -> "Step 1-2 (CP-6)" -> "Step 3 (CP-7)" -> "Step 4 (Sakuramil)" -> "Drug substance\\n(< 0.10%)";' \
              '"CP-8 impurities" -> "Step 4 (Sakuramil)"; }'
    else:  # control strategy
        src = 'digraph G { rankdir=LR; node [shape=box, style=rounded, fontname="Helvetica", fontsize=10];' \
              '"Material controls" -> "Process controls\\n(CPPs, IPCs)" -> "Drug product specification" -> "Continued process verification"; }'
    return _dot(src)


# ----------------------------------------------------------------------------- documents and illustrations
def certificate(caption):
    fig = plt.figure(figsize=(6.5, 8.4)); ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
    ax.add_patch(plt.Rectangle((0.05, 0.03), 0.9, 0.94, fill=False, lw=1))
    ax.text(0.5, 0.92, caption.split("  ")[-1].strip()[:70], ha="center", fontsize=11, weight="bold", wrap=True)
    ax.text(0.5, 0.87, "SYNTHETIC EXAMPLE – NOT A REAL CERTIFICATE", ha="center", fontsize=9, color="#b91c1c")
    rows = [("Test", "Specification", "Result"), ("Appearance", "Conforms", "Conforms"), ("Identification (IR)", "Conforms", "Conforms"),
            ("Assay", "98.0–102.0%", "100.2%"), ("Loss on drying", "≤ 0.5%", "0.1%"), ("Related substances", "≤ 1.0%", "0.1%")]
    for i, r in enumerate(rows):
        y = 0.78 - i * 0.05
        for j, v in enumerate(r): ax.text(0.1 + j * 0.3, y, v, fontsize=9, weight="bold" if i == 0 else None)
    ax.text(0.1, 0.38, "Conclusion: the batch complies with the specification.", fontsize=9)
    ax.text(0.1, 0.30, "Released by: Quality Assurance (synthetic)", fontsize=9)
    return _png(fig)


def configuration():
    fig, ax = plt.subplots(figsize=(8, 3.4)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 4)
    ax.add_patch(plt.Circle((1.6, 2), 1.0, color="#f4a6a6", ec="#9b4c4c", lw=1.5)); ax.text(1.6, 2, "SB", ha="center", va="center", fontsize=14, weight="bold", color="#7a2e2e")
    ax.text(1.6, 0.5, "Film-coated tablet, 20 mg\npale red, round, 'SB' / '20'", ha="center", fontsize=8)
    ax.add_patch(plt.Rectangle((4.2, 0.9), 1.4, 2.2, color="#f5f5f5", ec="black")); ax.add_patch(plt.Rectangle((4.35, 3.1), 1.1, 0.4, color="#cfd8dc", ec="black"))
    ax.text(4.9, 0.5, "HDPE bottle, PP child-\nresistant cap, desiccant", ha="center", fontsize=8)
    ax.add_patch(plt.Rectangle((7.0, 1.2), 2.4, 1.6, color="#e0e0e0", ec="black"))
    for i in range(3):
        for j in range(2): ax.add_patch(plt.Circle((7.45 + i * 0.75, 1.65 + j * 0.7), 0.25, color="#f4a6a6", ec="#9b4c4c"))
    ax.text(8.2, 0.5, "PA/Al/PVC–aluminium blister", ha="center", fontsize=8)
    return _png(fig)


@functools.lru_cache(maxsize=None)
def pdf_image(name, mask=None):
    """An image from the synthetic PQI example PDFs, composited on white at its original resolution."""
    im = Image.open(os.path.join(PDF_IMG, name)).convert("RGB")
    if mask:
        a = Image.open(os.path.join(PDF_IMG, mask)).convert("L")
        bg = Image.new("RGB", im.size, "white"); bg.paste(im, mask=a); im = bg
    b = io.BytesIO(); im.save(b, format="PNG"); return b.getvalue()



def generic_chart(caption):
    c = caption.lower()
    rng = np.random.default_rng(int(hashlib.md5(caption.encode()).hexdigest()[:6], 16))
    if "contour" in c:
        fig, ax = plt.subplots(figsize=(5.5, 4.2))
        x, y = np.meshgrid(np.linspace(-1, 1, 60), np.linspace(-1, 1, 60))
        z = 0.08 + 0.05 * x + 0.03 * y + 0.04 * x * y + 0.02 * x ** 2
        cs = ax.contourf(x, y, z, 12, cmap="viridis"); fig.colorbar(cs, ax=ax, label="Impurity level (%)")
        ax.set_xlabel("Temperature (coded)"); ax.set_ylabel("Reagent equivalents (coded)")
    elif "contributing rate" in c:
        fig, ax = _fig(6, 3.8); names = ["Water amount", "Impeller speed", "Granulation time", "Drying temperature"]
        ax.bar(names, [52, 27, 14, 7]); ax.set_ylabel("Contribution (%)"); ax.tick_params(axis="x", labelsize=8)
    elif "fraction" in c:
        fig, ax = _fig(6, 3.8); fr = ["> 710 µm", "500–710", "250–500", "106–250", "< 106 µm"]
        ax.bar(fr, 100 + rng.normal(0, 1.5, 5)); ax.set_ylim(90, 110); ax.set_ylabel("Drug substance content (%)")
    else:
        fig, ax = _fig(6, 3.8)
        xl = ("Tableting rotation speed (rpm)" if "rotation speed" in c else "Agitation rate (rpm)" if "agitation" in c
              else "Time (min)" if "time" in c else "Sampling location" if "blend" in c else "Process parameter (coded level)")
        yl = ("Weight variation (RSD, %)" if "weight variation" in c else "Content variation (RSD, %)" if "content variation" in c
              else "Drug substance content (%)" if "content" in c or "blend" in c else "Granule particle size d50 (µm)" if "particle size" in c
              else "Reactor temperature (°C)" if "temperature profile" in c else "Level (%)")
        x = np.linspace(1, 10, 8)
        base = {"Drug substance content (%)": 100, "Granule particle size d50 (µm)": 180, "Reactor temperature (°C)": 25}.get(yl, 1.0)
        for i, lab in enumerate(["Condition A", "Condition B"] if "effects" in c else [None]):
            ax.plot(x, base * (1 + 0.01 * (i + 1) * (x - 5) / 5) + rng.normal(0, base * 0.004, x.size), "o-", ms=3, lw=1, label=lab)
        ax.set_xlabel(xl); ax.set_ylabel(yl)
        if "effects" in c: ax.legend(frameon=False, fontsize=8)
    ax.set_title(caption[:90], fontsize=9)
    return _png(fig)


def qtpp_diagram():
    return _dot('digraph G { rankdir=LR; node [shape=box, style=rounded, fontname="Helvetica", fontsize=10];'
                '"QTPP\\n(IR film-coated tablet, 20 mg)" -> "CQAs\\n(assay, content uniformity,\\ndissolution, impurities)";'
                '"CQAs\\n(assay, content uniformity,\\ndissolution, impurities)" -> "CMAs\\n(drug substance particle size)";'
                '"CQAs\\n(assay, content uniformity,\\ndissolution, impurities)" -> "CPPs\\n(granulation water, compression speed)"; }')


def placeholder(caption):
    fig = plt.figure(figsize=(6.5, 1.6)); ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
    ax.add_patch(plt.Rectangle((0.01, 0.04), 0.98, 0.92, fill=True, color="#f3f4f6", ec="#9ca3af"))
    ax.text(0.5, 0.62, caption[:95], ha="center", fontsize=9, weight="bold")
    ax.text(0.5, 0.32, "Image not included in the ICH Sakura Bloom mock-up extract", ha="center", fontsize=8, color="#6b7280")
    return _png(fig)

# ----------------------------------------------------------------------------- dispatcher
def render(meta):
    cap, ctx, page = re.sub(r"[\s\u2011]+", lambda m: "-" if m.group(0) == "\u2011" else " ", meta.get("caption") or meta["name"]).strip(), meta.get("ctx", ""), meta.get("page", "")
    c = cap.lower()
    sub = _which(cap) or _which(page)
    try:
        if "configuration" in c: return configuration(), SYN
        if "synthetic scheme" in c: return ds_flow(), DATA
        if "flow diagram" in c: return ds_flow(meta.get("seq")), DATA
        if "reaction scheme (cp-8)" in c or "manufacturing process (cp-8)" in page.lower() or (page.startswith("2.3.4.SM.M") and "cp-8" in page.lower()): return cp8_scheme(), STRUCT
        if "enantiomers and diastereomers" in c: return stereoisomers(), STRUCT
        if "mutagenic intermediates" in c: return _mol_png(["cp-4", "cp-6"]), STRUCT
        if re.search(r"nomenclature|structural formula", c) and sub: return _mol_png([sub], numbers="nomenclature" in c), STRUCT
        if "nmr" in c: return nmr(cap, ctx), DATA
        if "mass spectrum" in c: return mass_spec(cap, ctx), DATA
        if "linearity" in c:
            p = linearity(cap, ctx)
            if p: return p, DATA
        if "chromatogram" in c or re.fullmatch(r"(figure\s*[\d‑\-\.]+\s*)?(blank|reference solution|test solution|identification solution|comparison solution)", c.strip()):
            return chromatogram(cap, ctx), DATA
        if "ir spectrum" in c: return pdf_image("3.2.S.3.1-005-002.png", "3.2.S.3.1-005-003.png"), PDF
        if "uv spectrum" in c: return pdf_image("3.2.S.3.1-004-000.png", "3.2.S.3.1-004-001.png"), PDF
        if "x-ray" in c or "xrpd" in c: return pdf_image("3.2.S.3.1-011-005.png", "3.2.S.3.1-011-006.png"), PDF
        if "profile of the drug product" in c: return pdf_image("fda-ir-fig3.png"), FDA
        if "dissolution" in page.lower():
            tail = ctx[-700:].lower()
            if "discrimin" in tail: return pdf_image("fda-ir-fig2.png" if meta.get("seq", 0) == 0 and "[image" not in tail.split("discrimin")[-1] else "fda-ir-fig1.png"), FDA
            return pdf_image("fda-ir-fig3.png"), FDA
        if "dissolution" in c: return dissolution(cap, ctx), SYN
        if "storage" in page.lower() and "3.2.DS.S" in page: return pdf_image("3.2.P.8.3-005-000.png", "3.2.P.8.3-005-001.png"), PDF
        if re.search(r"coa|certificate|statement of compliance", c): return certificate(cap), SYN
        if "fishbone" in c: return pdf_image("fda-ir-diagram1.png"), FDA
        if "contour" in c: return pdf_image("fda-ir-fig5.png"), FDA
        if re.search(r"control strategy|fate and purge|cascade|process-related", c): return generic_diagram(cap), SYN
        if "reaction scheme (cp-4" in c: return _mol_png(["cp-4"]), STRUCT
        if re.search(r"synthetic route|step 3 process", c): return ds_flow(), DATA
        if re.search(r"route [abc]:", c): return ds_flow(), SYN
        if "comparison spectrum" in c: return pdf_image("3.2.S.3.1-005-002.png", "3.2.S.3.1-005-003.png"), PDF
        if "qtpp" in c: return qtpp_diagram(), SYN
        if c.startswith("figure") and re.search(r"contour|effect|relation|profile|content|contributing|level|impurit|combination|strategy", c): return generic_chart(cap), SYN
    except Exception as e:  # never fail the build on one figure
        print("figure failed:", cap[:60], e)
    try:
        return placeholder(cap if not re.fullmatch(r"[A-Za-z0-9+/=]{30,}", cap) else "Figure"), None
    except Exception:
        pass
    return None, None
