"""The in-IG Sakura Bloom examples: one collection per PQI type holding the 3.2.P.3, 3.2.P.7 and 3.2.R (US) documents."""
import os, json
KEEP = ("3-2-p-3", "3-2-p-7", "3-2-r-us")

def write(full, out):
    for t in (1, 2, 3, 4):
        b = json.load(open(f"{full}/type{t}/bundle-document-collection-pq-sakura-bloom-m32-type{t}.json"))
        b["entry"] = [e for e in b["entry"] if e["resource"]["id"].split("sakura-bloom-m32-")[1] in KEEP]
        b["id"] = f"bundle-document-collection-pq-sakura-bloom-type{t}"
        b["identifier"]["value"] = b["identifier"]["value"][:-4] + f"{t:04d}"
        p = os.path.join(out, b["id"] + ".json")
        json.dump(b, open(p, "w"), ensure_ascii=False, indent=2)
        print("in-IG example:", p)
